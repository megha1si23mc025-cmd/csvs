
#!/usr/bin/env python3
# build_instructions_v2.py
import os, re, json, argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split

LABEL_TOKENS = ["<positive>", "<neutral>", "<negative>"]

def clean_text(t):
    if t is None or (isinstance(t, float) and np.isnan(t)): return None
    t = re.sub(r'http[s]?://\S+', '', str(t))
    t = re.sub(r'\s+', ' ', t).strip()
    return t or None

def simple_pros_cons(texts):
    """Weakly-supervised extractor: hunts for positive/negative phrases.
    Replace/extend with your domain lexicons or a rule-based classifier."""
    POS = ['good', 'great', 'amazing', 'excellent', 'fast', 'worth', 'value', 'clear', 'durable', 'perfect', 'works well', 'recommend']
    NEG = ['bad', 'poor', 'slow', 'issue', 'problem', 'broken', 'noise', 'lag', 'faulty', 'not working', 'disappointed']
    pros, cons = set(), set()
    for t in texts:
        lt = t.lower()
        if any(p in lt for p in POS): pros.add(t)
        if any(n in lt for n in NEG): cons.add(t)
    # keep top 3 unique snippets
    return list(pros)[:3], list(cons)[:3]

def label_from_rating_series(ratings):
    """Map numeric ratings (1–5) to label tokens via median/mean heuristic."""
    if ratings is None or len(ratings) == 0:
        return "<neutral>"
    vals = pd.to_numeric(ratings, errors="coerce").dropna().astype(float)
    if len(vals) == 0:
        return "<neutral>"
    m = float(vals.median())
    if m >= 4.0: return "<positive>"
    if m <= 2.0: return "<negative>"
    return "<neutral>"

def build_instructions(products_csv, reviews_csv, out_jsonl, out_train=None, out_val=None, test_size=0.15):
    prods = pd.read_csv(products_csv)
    revs  = pd.read_csv(reviews_csv)

    # Build product_id -> product_name/title map for nicer prompts
    pid_to_name = {}
    if "product_id" in prods.columns:
        name_col = "title_clean" if "title_clean" in prods.columns else ("title" if "title" in prods.columns else None)
        if name_col:
            pid_to_name = dict(zip(prods["product_id"], prods[name_col].fillna("").astype(str)))
    elif "title_clean" in prods.columns:
        # If no product_id, we will fall back to title later
        pass

    insts = []

    # --- Spec Q&A (TVs only) ---
    tvs = prods[prods['category_global'].eq('TVs')] if 'category_global' in prods.columns else prods
    for _, r in tvs.iterrows():
        title = clean_text(r.get('title_clean') or r.get('title'))
        screen = r.get('screen_inches')
        res    = r.get('resolution')
        hz     = r.get('refresh_hz')
        hdr    = r.get('hdr')
        parts  = []
        if pd.notna(screen): parts.append(f"Screen: {screen} inch")
        if pd.notna(res):    parts.append(f"Resolution: {res}")
        if pd.notna(hz):     parts.append(f"Refresh: {hz} Hz")
        if pd.notna(hdr):    parts.append(f"HDR: {hdr}")
        if not parts or title is None: continue
        insts.append({
            "instruction": "Answer TV specifications from trusted catalog data.",
            "input": f"Title: {title}\nQuestion: Provide screen size, resolution, refresh rate, and HDR standard.",
            "response": "; ".join(parts)
        })

    # --- Review summarization + sentiment + example reviews (grouped by product) ---
    review_text_col = "review_text_clean" if "review_text_clean" in revs.columns else "review_text"
    if not review_text_col in revs.columns:
        raise ValueError(f"Reviews CSV must have '{review_text_col}' or 'review_text' column.")

    # If we have product_id, group by that; else fallback to title/product_name if present
    if "product_id" in revs.columns:
        group_key = "product_id"
    elif "product_name" in revs.columns:
        group_key = "product_name"
    else:
        group_key = None

    # Precompute a clean product_name column on reviews for nicer prompts
    if group_key == "product_id":
        revs["product_name_prompt"] = revs["product_id"].map(lambda pid: pid_to_name.get(pid, f"Product {pid}"))
    elif group_key == "product_name":
        revs["product_name_prompt"] = revs["product_name"].fillna("").astype(str)
    else:
        revs["product_name_prompt"] = revs.get("title_clean", revs.get("title", "Unknown Product")).fillna("").astype(str)

    # Group and create instruction examples
    if group_key is not None:
        grouped = revs.groupby(group_key)
        for gid, grp in grouped:
            texts = [clean_text(x) for x in grp[review_text_col].dropna().tolist()]
            texts = [t for t in texts if t]
            if len(texts) < 2:
                continue
            product_name = clean_text(grp["product_name_prompt"].iloc[0]) or f"Product {gid}"

            # Limit reviews per example to keep context size manageable
            texts = texts[:20]

            pros, cons = simple_pros_cons(texts)
            overall = label_from_rating_series(grp["rating"] if "rating" in grp.columns else None)

            # Pick sample reviews (top 2)
            examples = texts[:2] if len(texts) >= 2 else texts[:1]

            instruction = ("Given the product name and its reviews, summarize Pros, Cons, Verdict and "
                           "classify overall sentiment using one of <positive>/<neutral>/<negative>. "
                           "Also include 2 example reviews.")
            input_block = f"Product: {product_name}\nReviews:\n" + "\n".join([f"- {t}" for t in texts])

            response = (
                "Summary:\n"
                f"Pros: {', '.join(pros) if pros else 'N/A'}\n"
                f"Cons: {', '.join(cons) if cons else 'N/A'}\n"
                f"Verdict: {'Overall sentiment is positive.' if overall=='<positive>' else ('Overall sentiment is negative.' if overall=='<negative>' else 'Overall sentiment is mixed/neutral.')}\n"
                f"Overall Sentiment: {overall}\n"
                "Example Reviews:\n" + "\n".join([f"- {ex}" for ex in examples])
            )

            insts.append({
                "instruction": instruction,
                "input": input_block,
                "response": response
            })
    else:
        # Fallback: single big group if no keys (rare)
        texts = [clean_text(x) for x in revs[review_text_col].dropna().tolist()]
        texts = [t for t in texts if t]
        if len(texts) >= 2:
            product_name = "Unknown Product"
            pros, cons = simple_pros_cons(texts)
            overall = label_from_rating_series(revs["rating"] if "rating" in revs.columns else None)
            examples = texts[:2]
            instruction = ("Given the product name and its reviews, summarize Pros, Cons, Verdict and "
                           "classify overall sentiment using one of <positive>/<neutral>/<negative>. "
                           "Also include 2 example reviews.")
            input_block = f"Product: {product_name}\nReviews:\n" + "\n".join([f"- {t}" for t in texts])
            response = (
                "Summary:\n"
                f"Pros: {', '.join(pros) if pros else 'N/A'}\n"
                f"Cons: {', '.join(cons) if cons else 'N/A'}\n"
                f"Verdict: {'Overall sentiment is positive.' if overall=='<positive>' else ('Overall sentiment is negative.' if overall=='<negative>' else 'Overall sentiment is mixed/neutral.')}\n"
                f"Overall Sentiment: {overall}\n"
                "Example Reviews:\n" + "\n".join([f"- {ex}" for ex in examples])
            )
            insts.append({
                "instruction": instruction,
                "input": input_block,
                "response": response
            })

    # Write JSONL (full), and optional train/val splits
    os.makedirs(os.path.dirname(out_jsonl), exist_ok=True)
    with open(out_jsonl, "w", encoding="utf-8") as f:
        for ex in insts:
            f.write(json.dumps(ex, ensure_ascii=False) + "\n")
    print(f"[OK] Wrote {len(insts)} instruction examples to {out_jsonl}")

    if out_train and out_val:
        train, val = train_test_split(insts, test_size=test_size, random_state=42)
        with open(out_train, "w", encoding="utf-8") as f:
            for ex in train: f.write(json.dumps(ex, ensure_ascii=False) + "\n")
        with open(out_val, "w", encoding="utf-8") as f:
            for ex in val: f.write(json.dumps(ex, ensure_ascii=False) + "\n")
        print(f"[OK] Split -> train: {len(train)}, val: {len(val)}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--silver-dir", default="data/silver")
    ap.add_argument("--out-jsonl", default="data/silver/electronics_instruct_v2.jsonl")
    ap.add_argument("--out-train", default="data/silver/train.jsonl")
    ap.add_argument("--out-val",   default="data/silver/val.jsonl")
    ap.add_argument("--test-size", type=float, default=0.15)
    args = ap.parse_args()
    products_csv = os.path.join(args.silver_dir, "electronics_products_master.csv")
    reviews_csv  = os.path.join(args.silver_dir, "electronics_reviews_events.csv")
    build_instructions(products_csv, reviews_csv, args.out_jsonl, args.out_train, args.out_val, args.test_size)
