
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Build Silver Layer (Electronics): Products master + Reviews events
------------------------------------------------------------------
- Reads raw (bronze) marketplace dumps (Walmart, Amazon, Flipkart).
- Cleans encodings, normalizes price/percent fields, canonicalizes brand/seller.
- Parses TV specs (screen_inches, resolution, refresh_hz, hdr) from Walmart catalog.
- Explodes Amazon's packed review columns into one review per row.
- Computes ratings_std from Walmart Individual_Ratings (review consistency).
- Deduplicates products & reviews.
- Saves two CSVs:
    electronics_products_master.csv
    electronics_reviews_events.csv

CLI:
  python build_silver.py --bronze-dir data/bronze --silver-dir data/silver

Notes:
- Walmart electronics-only file has a known placeholder price (49.0). We set those to NaN.
- Flipkart often needs non-UTF8 encodings; loader tries multiple encodings gracefully.
"""

import os
import re
import argparse
from typing import List, Optional

import numpy as np
import pandas as pd


# ------------------------------
# Helpers (robust to NaN/encodings)
# ------------------------------
def safe_read_csv(path: str) -> Optional[pd.DataFrame]:
    if not os.path.exists(path):
        print(f"[WARN] File not found: {path}")
        return None
    for enc in ['utf-8', 'utf-8-sig', 'latin1', 'cp1252', 'utf-16']:
        try:
            df = pd.read_csv(path, encoding=enc)
            print(f"[INFO] Loaded {os.path.basename(path)} with encoding={enc}, shape={df.shape}")
            return df
        except Exception:
            continue
    try:
        df = pd.read_csv(path)  # final attempt
        print(f"[INFO] Loaded {os.path.basename(path)} with default encoding, shape={df.shape}")
        return df
    except Exception as e:
        print(f"[ERROR] Failed to read {path}: {e}")
        return None


def canon(s):
    if s is None:
        return None
    try:
        if pd.isna(s):
            return None
    except Exception:
        pass
    return re.sub(r'\s+', ' ', str(s)).strip().title()


def to_num_price(s):
    if s is None:
        return np.nan
    try:
        if pd.isna(s):
            return np.nan
    except Exception:
        pass
    s = str(s).replace('₹', '').replace('$', '').replace(',', '').strip()
    # handle ranges like '299-399'
    if '-' in s:
        try:
            parts = [float(p) for p in s.split('-') if p]
            return float(np.mean(parts)) if parts else np.nan
        except Exception:
            pass
    return pd.to_numeric(s, errors='coerce')


def clean_text(t):
    if t is None:
        return None
    try:
        if pd.isna(t):
            return None
    except Exception:
        pass
    t = re.sub(r'http[s]?://\S+', '', str(t))  # strip URLs
    t = re.sub(r'\s+', ' ', t).strip()
    return t if t else None


def slug(s):
    if s is None:
        s = ''
    try:
        if pd.isna(s):
            s = ''
    except Exception:
        pass
    s = str(s).lower()
    return re.sub(r'[^a-z0-9]+', '-', re.sub(r'\s+', ' ', s)).strip('-')


def make_canonical_id(brand, model, title):
    def safe_str(x):
        try:
            if pd.isna(x):
                return ''
        except Exception:
            pass
        return str(x or '')
    b = safe_str(brand).lower().strip()
    m = safe_str(model).lower().strip()
    t = safe_str(title)
    if b and m:
        return f"{b}-{slug(m)}"
    return f"{b}-{slug(t)}" if b else slug(t)


def parse_list(s):
    if s is None:
        return []
    try:
        if pd.isna(s):
            return []
    except Exception:
        pass
    return [pd.to_numeric(x, errors='coerce') for x in str(s).split(',') if x != '']


def safe_lower(x):
    if x is None:
        return ''
    try:
        if pd.isna(x):
            return ''
    except Exception:
        pass
    return str(x).lower()


def map_category_global(platform_cat, title=None, subcat=None):
    """Simple heuristic mapping into global electronics taxonomy."""
    cat = safe_lower(platform_cat)
    if 'television' in cat or 'tv' in cat:
        return 'TVs'
    if 'laptop' in cat:
        return 'Laptops'
    if 'tablet' in cat:
        return 'Tablets'
    if 'mobile' in cat or 'smartphone' in cat or 'phone' in cat:
        return 'Mobiles'
    if 'headphone' in cat or 'earbud' in cat or 'audio' in cat or 'speaker' in cat:
        return 'Headphones/Audio'
    if 'camera' in cat:
        return 'Cameras'
    if 'smartwatch' in cat or 'wearable' in cat:
        return 'Smartwatches'
    if 'network' in cat or 'router' in cat:
        return 'Networking'
    t = safe_lower(title)
    if 'tv' in t or 'television' in t:
        return 'TVs'
    if 'router' in t or 'wifi' in t:
        return 'Networking'
    if 'headphone' in t or 'earbud' in t or 'speaker' in t:
        return 'Headphones/Audio'
    return 'Accessories'


def parse_inches(s):
    if s is None:
        return np.nan
    try:
        if pd.isna(s):
            s = ''
    except Exception:
        pass
    txt = str(s).lower()
    m = re.search(r'([0-9]+(?:\.[0-9]+)?)\s*(?:inch|\"| in\b)', txt)
    if m:
        return float(m.group(1))
    m2 = re.search(r'(\d{2,3})\s*\"', txt)
    return float(m2.group(1)) if m2 else np.nan


def parse_res(s):
    try:
        if pd.isna(s):
            s = ''
    except Exception:
        pass
    s = str(s).lower()
    if '8k' in s or '4320p' in s:
        return '8K'
    if '4k' in s or '2160p' in s or 'uhd' in s:
        return '4K'
    if '1080p' in s or 'full hd' in s:
        return '1080p'
    if '720p' in s or 'hd ' in s:
        return '720p'
    return None


def parse_hz(s):
    try:
        if pd.isna(s):
            s = ''
    except Exception:
        pass
    s = str(s).lower()
    m = re.search(r'(\d{2,3})\s*hz', s)
    return float(m.group(1)) if m else np.nan


def parse_hdr(s):
    try:
        if pd.isna(s):
            s = ''
    except Exception:
        pass
    s = str(s).lower()
    if 'dolby vision' in s:
        return 'Dolby Vision'
    if 'hdr10+' in s:
        return 'HDR10+'
    if 'hdr10' in s:
        return 'HDR10'
    if 'hlg' in s:
        return 'HLG'
    return None


# ------------------------------
# Core pipeline
# ------------------------------
def build_products_and_reviews(bronze_dir: str, silver_dir: str) -> None:
    os.makedirs(silver_dir, exist_ok=True)

    # --- Load bronze files ---
    wm_cat   = safe_read_csv(os.path.join(bronze_dir, 'finalwalmartedited.csv'))
    wm_all   = safe_read_csv(os.path.join(bronze_dir, 'walmart_products_reviews_30000.csv'))
    wm_elec  = safe_read_csv(os.path.join(bronze_dir, 'walmart_electronics_reviews_30000.csv'))
    amazon   = safe_read_csv(os.path.join(bronze_dir, 'amazon.csv'))
    flipkart = safe_read_csv(os.path.join(bronze_dir, 'flipkart_product.csv'))

    # --- Filter Walmart-all to electronics ---
    if wm_all is not None and 'Category' in wm_all.columns:
        wm_all_e = wm_all[wm_all['Category'].apply(lambda x: safe_lower(x) == 'electronics')].copy()
    else:
        wm_all_e = wm_all.copy() if wm_all is not None else None

    # --- Walmart electronics-only: $49 placeholders -> NaN ---
    if wm_elec is not None and 'Price' in wm_elec.columns:
        mask = wm_elec['Price'].eq(49.0)
        n = int(mask.sum())
        if n:
            print(f"[INFO] Walmart electronics-only: setting {n} placeholder $49 prices to NaN")
        wm_elec.loc[mask, 'Price'] = np.nan

    # --- Attach platform ---
    for df, plat in [(wm_cat, 'Walmart'), (wm_all_e, 'Walmart'), (wm_elec, 'Walmart'),
                     (amazon, 'Amazon'), (flipkart, 'Flipkart')]:
        if df is not None:
            df['platform'] = plat

    # --- Canonicalize brand/seller ---
    for df in [wm_cat, wm_all_e, wm_elec, amazon, flipkart]:
        if df is None:
            continue
        if 'Brand' in df.columns:
            df['brand_canon'] = df['Brand'].apply(canon)
        elif 'Manufacturer' in df.columns:
            df['brand_canon'] = df['Manufacturer'].apply(canon)
        else:
            df['brand_canon'] = None

        df['seller_canon'] = df['Seller'].apply(canon) if 'Seller' in df.columns else None

    # --- Prices for Amazon/Flipkart (assume INR) ---
    for df in [amazon, flipkart]:
        if df is None:
            continue
        found_any = False
        for col in ['discounted_price', 'actual_price', 'price', 'Price']:
            if col in df.columns:
                df[col + '_num'] = df[col].apply(to_num_price)
                found_any = True
        if found_any:
            df['currency'] = 'INR'

    # --- Walmart catalog: parse TV specs ---
    if wm_cat is not None:
        wm_cat['screen_inches'] = wm_cat['Screen Size'].apply(parse_inches) if 'Screen Size' in wm_cat.columns else np.nan
        if 'Specifications' in wm_cat.columns:
            wm_cat['resolution']  = wm_cat['Specifications'].apply(parse_res)
            wm_cat['refresh_hz']  = wm_cat['Specifications'].apply(parse_hz)
            wm_cat['hdr']         = wm_cat['Specifications'].apply(parse_hdr)
        else:
            wm_cat['resolution'] = wm_cat['refresh_hz'] = wm_cat['hdr'] = None

        wm_cat['category_global'] = wm_cat.apply(lambda r: map_category_global(None, r.get('Title'), None), axis=1)

    # --- Walmart review rating consistency ---
    for df in [wm_all_e, wm_elec]:
        if df is None:
            continue
        if 'Individual_Ratings' in df.columns:
            df['ratings_list'] = df['Individual_Ratings'].apply(parse_list)
            df['ratings_std']  = df['ratings_list'].apply(lambda xs: np.nan if len(xs) < 2 else float(np.nanstd(xs)))
        else:
            df['ratings_std'] = np.nan

    # ---------- Build products_master ----------
    products = []

    # Walmart catalog contributes the richest product attributes
    if wm_cat is not None:
        for _, r in wm_cat.iterrows():
            products.append({
                'platform': 'Walmart',
                'product_id': r.get('Sku') if 'Sku' in wm_cat.columns else None,
                'canonical_product_id': make_canonical_id(r.get('brand_canon'), r.get('Model Num'), r.get('Title')),
                'title_clean': clean_text(r.get('Title')),
                'brand_canon': r.get('brand_canon'),
                'model_num': r.get('Model Num'),
                'model_name': r.get('Model Name'),
                'category_global': r.get('category_global'),
                'price_numeric': to_num_price(r.get('Price')) if 'Price' in wm_cat.columns else np.nan,
                'currency': 'USD',
                'seller_canon': r.get('seller_canon'),
                'availability': r.get('Stock'),
                'discontinued': r.get('Discontinued'),
                'broken_link': r.get('Broken Link'),
                'screen_inches': r.get('screen_inches'),
                'resolution': r.get('resolution'),
                'refresh_hz': r.get('refresh_hz'),
                'hdr': r.get('hdr'),
                'source_url': r.get('Pageurl')
            })

    # Amazon
    if amazon is not None:
        for _, r in amazon.iterrows():
            price = None
            for col in ['discounted_price_num', 'actual_price_num', 'price_num', 'Price_num']:
                if col in amazon.columns and pd.notna(r.get(col)):
                    price = r.get(col)
                    break
            products.append({
                'platform': 'Amazon',
                'product_id': r.get('product_id'),
                'canonical_product_id': make_canonical_id(r.get('brand_canon'), None, r.get('product_name')),
                'title_clean': clean_text(r.get('product_name')),
                'brand_canon': r.get('brand_canon'),
                'model_num': None,
                'model_name': None,
                'category_global': map_category_global(r.get('category'), r.get('product_name'), None),
                'price_numeric': price,
                'currency': r.get('currency') or 'INR',
                'seller_canon': r.get('seller_canon'),
                'availability': None,
                'discontinued': None,
                'broken_link': None,
                'screen_inches': parse_inches(r.get('product_name')),
                'resolution': None,
                'refresh_hz': None,
                'hdr': None,
                'source_url': r.get('product_link')
            })

    # Flipkart
    if flipkart is not None:
        title_col = 'product_name' if 'product_name' in flipkart.columns else ('title' if 'title' in flipkart.columns else None)
        pid_col   = 'product_id' if 'product_id' in flipkart.columns else ('id' if 'id' in flipkart.columns else None)
        price_col = 'discounted_price_num' if 'discounted_price_num' in flipkart.columns else ('price_num' if 'price_num' in flipkart.columns else None)
        cat_col   = 'category' if 'category' in flipkart.columns else None
        for _, r in flipkart.iterrows():
            products.append({
                'platform': 'Flipkart',
                'product_id': r.get(pid_col),
                'canonical_product_id': make_canonical_id(r.get('brand_canon'), None, r.get(title_col)),
                'title_clean': clean_text(r.get(title_col)),
                'brand_canon': r.get('brand_canon'),
                'model_num': None,
                'model_name': None,
                'category_global': map_category_global(r.get(cat_col), r.get(title_col), None),
                'price_numeric': r.get(price_col),
                'currency': r.get('currency') or 'INR',
                'seller_canon': r.get('seller_canon'),
                'availability': None,
                'discontinued': None,
                'broken_link': None,
                'screen_inches': parse_inches(r.get(title_col)),
                'resolution': None,
                'refresh_hz': None,
                'hdr': None,
                'source_url': r.get('product_link') if 'product_link' in flipkart.columns else None
            })

    products_df = pd.DataFrame(products)
    if not products_df.empty:
        if 'product_id' in products_df.columns:
            products_df = products_df.drop_duplicates(subset=['platform', 'product_id'], keep='first')
        products_df = products_df.drop_duplicates(subset=['canonical_product_id', 'title_clean'], keep='first')
    else:
        print("[WARN] No products constructed; check input files.")

    # ---------- Build reviews_events ----------
    reviews: List[dict] = []

    # Walmart all electronics reviews
    if wm_all_e is not None and not wm_all_e.empty:
        for _, r in wm_all_e.iterrows():
            reviews.append({
                'platform': 'Walmart',
                'product_id': r.get('Product_ID'),
                'review_id': r.get('Reviewer_ID'),
                'review_date': r.get('Review_Date'),
                'reviewer_id': r.get('Reviewer_ID'),
                'reviewer_name': r.get('Reviewer_Name'),
                'rating': r.get('Average_Rating'),
                'ratings_std': r.get('ratings_std'),
                'review_text_clean': clean_text(r.get('Customer_Reviews')),
                'seller_canon_at_review': r.get('seller_canon'),
                'source_url': r.get('Product_Page_URL')
            })

    # Walmart electronics-only reviews (for text + rating; price was sanitized earlier)
    if wm_elec is not None and not wm_elec.empty:
        for _, r in wm_elec.iterrows():
            reviews.append({
                'platform': 'Walmart',
                'product_id': r.get('Product_ID'),
                'review_id': r.get('Reviewer_ID'),
                'review_date': r.get('Review_Date'),
                'reviewer_id': r.get('Reviewer_ID'),
                'reviewer_name': r.get('Reviewer_Name'),
                'rating': r.get('Average_Rating'),
                'ratings_std': r.get('ratings_std'),
                'review_text_clean': clean_text(r.get('Customer_Reviews')),
                'seller_canon_at_review': r.get('seller_canon'),
                'source_url': r.get('Product_Page_URL')
            })

    # Amazon exploded multi-review rows
    if amazon is not None and not amazon.empty:
        def split_list(val):
            try:
                if pd.isna(val):
                    return []
            except Exception:
                pass
            return [x.strip() for x in str(val).split(',') if x.strip() != '']

        for _, row in amazon.iterrows():
            user_ids        = split_list(row.get('user_id'))        if 'user_id'        in amazon.columns else []
            user_names      = split_list(row.get('user_name'))      if 'user_name'      in amazon.columns else []
            review_ids      = split_list(row.get('review_id'))      if 'review_id'      in amazon.columns else []
            review_titles   = split_list(row.get('review_title'))   if 'review_title'   in amazon.columns else []
            review_contents = split_list(row.get('review_content')) if 'review_content' in amazon.columns else []
            max_len = max([len(user_ids), len(user_names), len(review_ids), len(review_titles), len(review_contents), 1])

            def pad(lst): return lst + [None] * (max_len - len(lst))
            user_ids, user_names, review_ids, review_titles, review_contents = map(
                pad, [user_ids, user_names, review_ids, review_titles, review_contents]
            )

            for i in range(max_len):
                txt  = (review_titles[i] or '')
                body = (review_contents[i] or '')
                txt_clean = clean_text(f"{txt}. {body}") if (txt or body) else None
                reviews.append({
                    'platform': 'Amazon',
                    'product_id': row.get('product_id'),
                    'review_id': review_ids[i],
                    'review_date': None,  # not present per-review in provided csv
                    'reviewer_id': user_ids[i],
                    'reviewer_name': user_names[i],
                    'rating': row.get('rating'),  # row-level rating
                    'ratings_std': None,
                    'review_text_clean': txt_clean,
                    'seller_canon_at_review': row.get('seller_canon'),
                    'source_url': row.get('product_link')
                })

    reviews_df = pd.DataFrame(reviews)
    if not reviews_df.empty:
        # Ensure keys exist
        for c in ['platform', 'product_id', 'review_id', 'review_text_clean']:
            if c not in reviews_df.columns:
                reviews_df[c] = None
        # Deduplicate
        reviews_df = reviews_df.drop_duplicates(
            subset=['platform', 'product_id', 'review_id', 'review_text_clean'],
            keep='first'
        )
        # Dates
        if 'review_date' in reviews_df.columns:
            reviews_df['review_date'] = pd.to_datetime(reviews_df['review_date'], errors='coerce')
    else:
        print("[WARN] No reviews constructed; check input files.")

    # --- Save Silver outputs ---
    products_out = os.path.join(silver_dir, 'electronics_products_master.csv')
    reviews_out  = os.path.join(silver_dir, 'electronics_reviews_events.csv')

    products_df.to_csv(products_out, index=False)
    reviews_df.to_csv(reviews_out, index=False)

    print(f"[OK] Saved products -> {products_out}  (rows={len(products_df)})")
    print(f"[OK] Saved reviews  -> {reviews_out}   (rows={len(reviews_df)})")


# ------------------------------
# CLI
# ------------------------------
def main():
    parser = argparse.ArgumentParser(description="Build Silver Electronics tables: Products + Reviews")
    parser.add_argument('--bronze-dir', type=str, default='data/bronze', help='Path to raw inputs directory')
    parser.add_argument('--silver-dir', type=str, default='data/silver', help='Output directory for cleaned tables')
    args = parser.parse_args()

    build_products_and_reviews(args.bronze_dir, args.silver_dir)


if __name__ == '__main__':
    main()
