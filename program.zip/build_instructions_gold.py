
# build_instructions_gold.py
import json
from pathlib import Path
import pandas as pd

# --- Paths (adjust only if you moved files) ---
SPLITS_DIR = r"C:\Users\mk17\OneDrive - Capgemini\Documents\Ecommerce_Review_Intelli\src\pipline\data\gold\splits"
PRODUCTS_CSV = r"C:\Users\mk17\OneDrive - Capgemini\Documents\Ecommerce_Review_Intelli\src\pipline\data\silver\electronics_products_master.csv"
OUT_DIR = r"C:\Users\mk17\OneDrive - Capgemini\Documents\Ecommerce_Review_Intelli\src\pipline\data\gold\instructions"

Path(OUT_DIR).mkdir(parents=True, exist_ok=True)

def load_split(name: str) -> pd.DataFrame:
    df = pd.read_csv(Path(SPLITS_DIR) / f"reviews_{name}.csv")
    return df

def label_from_rating(x):
    # Heuristic: convert numeric rating to sentiment label
    try:
        r = float(x)
    except Exception:
        return "Neutral"
    if r >= 4: return "Positive"
    if r <= 2: return "Negative"
    return "Neutral"

def build_examples(df_reviews: pd.DataFrame, df_products: pd.DataFrame):
    # Join minimal product context
    cols_available = [c for c in ["title_clean","brand_canon","category_global"] if c in df_products.columns]
    join_cols = ["product_id"] + cols_available
    df = df_reviews.merge(df_products[join_cols], on="product_id", how="left")

    # Choose review text column
    text_col = None
    for cand in ["review_text_clean", "text", "review_text", "body", "content"]:
        if cand in df.columns:
            text_col = cand; break
    if text_col is None:
        # Fallback so script never crashes
        df["text"] = ""
        text_col = "text"

    examples = []

    for _, r in df.iterrows():
        review_text = (str(r[text_col]) if pd.notna(r[text_col]) else "").strip()
        if not review_text:
            continue

        product_name = (str(r.get("title_clean","")) if pd.notna(r.get("title_clean","")) else "").strip()
        brand        = (str(r.get("brand_canon","")) if pd.notna(r.get("brand_canon","")) else "").strip()
        category     = (str(r.get("category_global","")) if pd.notna(r.get("category_global","")) else "").strip()

        context_parts = []
        if product_name: context_parts.append(f"Product: {product_name}")
        if brand:        context_parts.append(f"Brand: {brand}")
        if category:     context_parts.append(f"Category: {category}")
        context = " | ".join(context_parts)

        # --- Task 1: Sentiment (supervised from rating) ---
        if "rating" in df.columns:
            sentiment = label_from_rating(r.get("rating"))
            prompt_sent = (
                (context + "\n\n") if context else "" +
                "Task: Classify sentiment of the following e-commerce review as Positive, Neutral, or Negative.\n\n"
                f"Review:\n{review_text}\n\nSentiment:"
            )
            examples.append({"task":"sentiment","prompt":prompt_sent,"response":sentiment})

        # --- Task 2: Summarization (optional; only if label exists) ---
        target_sum = r.get("summary", None)
        if target_sum and pd.notna(target_sum) and str(target_sum).strip():
            prompt_sum = (
                (context + "\n\n") if context else "" +
                "Task: Summarize the following product review in 2-3 concise sentences.\n\n"
                f"Review:\n{review_text}\n\nSummary:"
            )
            examples.append({"task":"summarize","prompt":prompt_sum,"response":str(target_sum).strip()})

        # --- Task 3: Pros/Cons (optional; only if label exists) ---
        target_pc = r.get("pros_cons_json", None)
        if target_pc and pd.notna(target_pc) and str(target_pc).strip():
            prompt_pc = (
                (context + "\n\n") if context else "" +
                "Task: Extract key Pros and Cons from this review. Respond strictly as JSON with keys 'pros' and 'cons'.\n\n"
                f"Review:\n{review_text}\n\nJSON:"
            )
            examples.append({"task":"pros_cons","prompt":prompt_pc,"response":str(target_pc).strip()})

        # --- Optional extensions (add later if you create labels) ---
        # Verdict -> r.get("verdict")
        # Key themes -> r.get("themes_json")

    return examples

def save_jsonl(path: str, rows: list[dict]):
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")

if __name__ == "__main__":
    print("Loading products and splits ...")
    df_products = pd.read_csv(PRODUCTS_CSV)

    train = load_split("train")
    val   = load_split("val")
    test  = load_split("test")

    print("Building instruction examples ...")
    ex_train = build_examples(train, df_products)
    ex_val   = build_examples(val, df_products)
    ex_test  = build_examples(test, df_products)

    out_train = Path(OUT_DIR) / "electronics_instruct_train.jsonl"
    out_val   = Path(OUT_DIR) / "electronics_instruct_val.jsonl"
    out_test  = Path(OUT_DIR) / "electronics_instruct_test.jsonl"

    save_jsonl(out_train.as_posix(), ex_train)
    save_jsonl(out_val.as_posix(),   ex_val)
    save_jsonl(out_test.as_posix(),  ex_test)

    print("✅ Instruction JSONL written to:", OUT_DIR)
    print("Counts:", {"train":len(ex_train), "val":len(ex_val), "test":len(ex_test)})
