
# src/pipline/split_quick.py
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

def ensure_cols(df, cols, name):
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise ValueError(f"{name} missing columns: {missing}")

def to_band_price(x):
    try:
        x = float(x)
    except:
        return "unknown"
    if x < 1000: return "low"
    if x < 5000: return "mid"
    if x < 15000: return "high"
    return "premium"

def time_split_grouped(df, date_col="review_date", train_frac=0.8, val_frac=0.1):
    """
    Split per product_id: sort by date, then take fractions per product.
    This reduces leakage and respects each product's timeline.
    """
    parts_tr, parts_va, parts_te = [], [], []
    # If date_col missing, we'll just use the existing order per group
    for pid, g in df.groupby("product_id"):
        if date_col in g.columns:
            g = g.sort_values(date_col)
        n = len(g)
        if n == 0:
            continue
        tr_end = int(n * train_frac)
        va_end = tr_end + int(n * val_frac)
        parts_tr.append(g.iloc[:tr_end])
        parts_va.append(g.iloc[tr_end:va_end])
        parts_te.append(g.iloc[va_end:])
    tr = pd.concat(parts_tr, ignore_index=True) if parts_tr else df.iloc[0:0]
    va = pd.concat(parts_va, ignore_index=True) if parts_va else df.iloc[0:0]
    te = pd.concat(parts_te, ignore_index=True) if parts_te else df.iloc[0:0]
    return tr, va, te

def main(args):
    outdir = Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)

    products = pd.read_csv(args.products)
    reviews  = pd.read_csv(args.reviews)

    # --- Print columns to help debugging ---
    print("Products columns:", list(products.columns))
    print("Reviews columns:",  list(reviews.columns))

    # --- Required keys ---
    ensure_cols(products, ["product_id"], "products")
    ensure_cols(reviews, ["review_id", "product_id"], "reviews")

    # --- Normalize product-side columns to your schema ---
    category_col = "category_global" if "category_global" in products.columns else None
    brand_col    = "brand_canon"     if "brand_canon"     in products.columns else None
    price_col    = "price_numeric"   if "price_numeric"   in products.columns else None

    products["__category__"] = products[category_col] if category_col else "other"
    products["__brand__"]    = products[brand_col]    if brand_col    else "unknown"
    products["__price__"]    = products[price_col]    if price_col    else np.nan

    # --- Parse review date if present ---
    date_col = "review_date" if "review_date" in reviews.columns else None
    if date_col:
        reviews[date_col] = pd.to_datetime(reviews[date_col], errors="coerce")

    # --- Create a globally unique review key and de-duplicate ---
    # This avoids collisions where the same review_id appears under different products/platforms.
    platform_col = "platform" if "platform" in reviews.columns else None
    def make_uid(row):
        plat = str(row[platform_col]) if platform_col and platform_col in row else ""
        return f"{plat}|{str(row['product_id'])}|{str(row['review_id'])}"
    reviews["review_uid"] = reviews.apply(make_uid, axis=1)
    before = len(reviews)
    reviews = reviews.drop_duplicates(subset=["review_uid"])
    after = len(reviews)
    print(f"De-duplicated reviews on review_uid: {before} -> {after}")

    # --- Popularity bands for stratification ---
    pop = reviews.groupby("product_id")["review_uid"].count().rename("num_reviews")
    products = products.merge(pop, on="product_id", how="left").fillna({"num_reviews": 0})

    # Use wider bins and lower category threshold to reduce 'single-member' strata
    products["pop_band"] = pd.cut(
        products["num_reviews"], bins=[-1, 20, 100, 10**9], labels=["low", "mid", "high"]
    ).astype(str)
    products["price_band"] = products["__price__"].apply(to_band_price)
    cats = products["__category__"].value_counts()
    keep = cats[cats >= 20].index                                             # was 50; reduce to 20
    products["category_slim"] = products["__category__"].where(products["__category__"].isin(keep), "other")

    products["strata"] = (
        products["category_slim"].astype(str) + "|" +
        products["price_band"].astype(str)    + "|" +
        products["pop_band"].astype(str)
    )

    # --- Product-level split: try stratified; else random ---
    try:
        train_prod, temp_prod = train_test_split(
            products, test_size=0.30, random_state=args.seed, stratify=products["strata"]
        )
        val_prod, test_prod = train_test_split(
            temp_prod, test_size=0.50, random_state=args.seed, stratify=temp_prod["strata"]
        )
    except Exception as e:
        print("⚠️ Stratified split failed; falling back to random split:", e)
        train_prod, temp_prod = train_test_split(products, test_size=0.30, random_state=args.seed)
        val_prod, test_prod   = train_test_split(temp_prod, test_size=0.50, random_state=args.seed)

    train_ids = set(train_prod["product_id"])
    val_ids   = set(val_prod["product_id"])
    test_ids  = set(test_prod["product_id"])

    # --- Assign reviews to product subsets ---
    r_train_p = reviews[reviews["product_id"].isin(train_ids)].copy()
    r_val_p   = reviews[reviews["product_id"].isin(val_ids)].copy()
    r_test_p  = reviews[reviews["product_id"].isin(test_ids)].copy()

    # --- Find review text column (so downstream has text) ---
    text_col = None
    for cand in ["review_text_clean", "text", "review_text", "body", "content", "title_clean"]:
        if cand in reviews.columns:
            text_col = cand; break
    if text_col is None:
        r_train_p["text"] = ""; r_val_p["text"] = ""; r_test_p["text"] = ""
        text_col = "text"

    # --- Grouped time-based splits to avoid leakage per product ---
    trA, vaA, teA = time_split_grouped(r_train_p, date_col or "review_date", train_frac=0.80, val_frac=0.10)
    trB, vaB, teB = time_split_grouped(r_val_p,   date_col or "review_date", train_frac=0.00, val_frac=0.50)  # val/test only
    trC, vaC, teC = time_split_grouped(r_test_p,  date_col or "review_date", train_frac=0.00, val_frac=0.00)  # test only

    train_reviews = pd.concat([trA], ignore_index=True)
    val_reviews   = pd.concat([vaA, vaB], ignore_index=True)
    test_reviews  = pd.concat([teA, teB, teC], ignore_index=True)

    # --- Final guard: ensure no overlap on the unique key review_uid ---
    def assert_disjoint(a, b, an, bn):
        inter = set(a).intersection(set(b))
        if inter:
            raise AssertionError(f"Leakage: {an} ∩ {bn} has {len(inter)} unique review_uids")

    assert_disjoint(train_reviews["review_uid"], val_reviews["review_uid"], "train", "val")
    assert_disjoint(train_reviews["review_uid"], test_reviews["review_uid"], "train", "test")
    assert_disjoint(val_reviews["review_uid"],   test_reviews["review_uid"], "val", "test")

    # --- Save outputs ---
    train_reviews.to_csv(outdir / "reviews_train.csv", index=False)
    val_reviews.to_csv(outdir / "reviews_val.csv", index=False)
    test_reviews.to_csv(outdir / "reviews_test.csv", index=False)

    train_prod["product_id"].to_csv(outdir / "products_train_ids.csv", index=False)
    val_prod["product_id"].to_csv(outdir / "products_val_ids.csv", index=False)
    test_prod["product_id"].to_csv(outdir / "products_test_ids.csv", index=False)

    manifest = {
        "strategy": "hybrid(product-level split + per-product time-based within subset)",
        "seed": args.seed,
        "normalized_fields": {
            "category": category_col or "synthetic('other')",
            "brand": brand_col or "synthetic('unknown')",
            "price": price_col or "synthetic(NaN)"
        },
        "review_uid_definition": "platform|product_id|review_id",
        "counts": {
            "products": {"train": len(train_ids), "val": len(val_ids), "test": len(test_ids)},
            "reviews":  {"train": int(train_reviews.shape[0]), "val": int(val_reviews.shape[0]), "test": int(test_reviews.shape[0])}
        }
    }
    (outdir / "split_manifest.json").write_text(json.dumps(manifest, indent=2))
    print(f"✅ Done. Files written to: {outdir.resolve()}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--products", default=r"C:\Users\mk17\OneDrive - Capgemini\Documents\Ecommerce_Review_Intelli\src\pipline\data\silver\electronics_products_master (1).csv")
    parser.add_argument("--reviews",  default=r"C:\Users\mk17\OneDrive - Capgemini\Documents\Ecommerce_Review_Intelli\src\pipline\data\silver\electronics_reviews_events (1).csv")
    parser.add_argument("--outdir",   default=r"C:\Users\mk17\OneDrive - Capgemini\Documents\Ecommerce_Review_Intelli\src\pipline\data\gold\splits")
    parser.add_argument("--seed",     type=int, default=42)
    args = parser.parse_args()
    main(args)
