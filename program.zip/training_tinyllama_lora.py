
import os
from datasets import load_dataset
from transformers import (
    AutoTokenizer, AutoModelForCausalLM,
    TrainingArguments, DataCollatorForLanguageModeling, Trainer
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
import torch

# --- Paths ---
DATA_DIR = r"C:\Users\mk17\OneDrive - Capgemini\Documents\Ecommerce_Review_Intelli\src\pipline\data\gold\instructions"
TRAIN_JSONL = os.path.join(DATA_DIR, "electronics_instruct_train.jsonl")
VAL_JSONL   = os.path.join(DATA_DIR, "electronics_instruct_val.jsonl")

OUTPUT_DIR = r"C:\Users\mk17\OneDrive - Capgemini\Documents\Ecommerce_Review_Intelli\models\tinyllama_lora"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Hugging Face base model (auto-downloaded)
MODEL_NAME = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"

# On Windows, set to False if bitsandbytes gives errors
USE_QLORA = True

def load_data():
    ds_train = load_dataset("json", data_files=TRAIN_JSONL)["train"]
    ds_val   = load_dataset("json", data_files=VAL_JSONL)["train"]
    def join_text(ex):
        return {"text": ex["prompt"] + " " + ex["response"]}
    ds_train = ds_train.map(join_text, remove_columns=ds_train.column_names)
    ds_val   = ds_val.map(join_text,   remove_columns=ds_val.column_names)
    return ds_train, ds_val

def main():
    ds_train, ds_val = load_data()

    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.add_special_tokens({"pad_token": tokenizer.eos_token})

    def tok(batch):
        return tokenizer(
            batch["text"],
            max_length=1024,
            truncation=True,
            padding="max_length"
        )

    ds_train = ds_train.map(tok, batched=True, remove_columns=["text"])
    ds_val   = ds_val.map(tok,   batched=True, remove_columns=["text"])

    if USE_QLORA:
        model = AutoModelForCausalLM.from_pretrained(
            MODEL_NAME,
            load_in_4bit=True,
            torch_dtype=torch.bfloat16,
            device_map="auto"
        )
        model = prepare_model_for_kbit_training(model)
    else:
        model = AutoModelForCausalLM.from_pretrained(
            MODEL_NAME,
            torch_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32,
            device_map="auto"
        )

    lora_cfg = LoraConfig(
        r=16, lora_alpha=32, lora_dropout=0.05,
        bias="none", task_type="CAUSAL_LM",
        target_modules=["q_proj","k_proj","v_proj","o_proj","gate_proj","up_proj","down_proj"]
    )
    model = get_peft_model(model, lora_cfg)

    data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)

    training_args = TrainingArguments(
        output_dir=OUTPUT_DIR,
        num_train_epochs=3,
        per_device_train_batch_size=2,
        per_device_eval_batch_size=2,
        gradient_accumulation_steps=16,
        learning_rate=2e-4,
        warmup_steps=100,
        logging_steps=50,
        evaluation_strategy="steps",
        eval_steps=200,
        save_steps=200,
        save_total_limit=3,
        bf16=torch.cuda.is_available(),
        gradient_checkpointing=True,
        optim="paged_adamw_32bit" if USE_QLORA else "adamw_torch",
        report_to="none"
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        data_collator=data_collator,
        train_dataset=ds_train,
        eval_dataset=ds_val
    )

    trainer.train()
    adapter_dir = os.path.join(OUTPUT_DIR, "adapter")
    model.save_pretrained(adapter_dir)
    tokenizer.save_pretrained(OUTPUT_DIR)
    print("✅ LoRA adapter saved to:", adapter_dir)

if __name__ == "__main__":
    main()
