
#!/usr/bin/env python3
# build_instructions.py
import os, re, json, argparse
import pandas as pd
import numpy as np

def clean_text(t):
    if t is None or (isinstance(t,float) and np.isnan(t)): return None
    t = re.sub(r'http[s]?://\S+', '', str(t))
    t = re.sub(r'\s+', ' ', t).strip()
    return t or None

def simple_pros_cons(texts):
    """Weakly-supervised extractor: hunts for positive/negative phrases.
    Replace/extend with your domain lexicons or a rule-based classifier."""
    POS = ['good', 'great', 'amazing', 'excellent', 'fast', 'worth', 'value', 'clear', 'durable', 'perfect', 'works well', 'recommend']
    NEG = ['bad', 'poor', 'slow', 'issue', 'problem', 'broken', 'noise', 'lag', 'faulty', 'not working', 'disappointed']
    pros, cons = set(), set()
    for t in texts:
        lt = t.lower()
        if any(p in lt for p in POS): pros.add(t)
        if any(n in lt for n in NEG): cons.add(t)
    # keep top 3 unique snippets
    return list(pros)[:3], list(cons)[:3]

def build_instructions(products_csv, reviews_csv, out_jsonl):
    prods = pd.read_csv(products_csv)
    revs  = pd.read_csv(reviews_csv)
    insts = []

    # --- Spec Q&A (TVs only, from products_master) ---
    tvs = prods[prods['category_global'].eq('TVs')] if 'category_global' in prods.columns else prods
    for _, r in tvs.iterrows():
        title = clean_text(r.get('title_clean'))
        screen = r.get('screen_inches')
        res    = r.get('resolution')
        hz     = r.get('refresh_hz')
        hdr    = r.get('hdr')
        parts  = []
        if pd.notna(screen): parts.append(f"Screen: {screen} inch")
        if pd.notna(res):    parts.append(f"Resolution: {res}")
        if pd.notna(hz):     parts.append(f"Refresh: {hz} Hz")
        if pd.notna(hdr):    parts.append(f"HDR: {hdr}")
        if not parts or title is None: continue
        insts.append({
            "instruction": "Answer TV specifications from trusted catalog data.",
            "input": f"Title: {title}\nQuestion: Provide screen size, resolution, refresh rate, and HDR standard.",
            "output": "; ".join(parts)
        })

    # --- Review summarization into Pros/Cons/Verdict (grouped by product) ---
    if 'product_id' in revs.columns:
        for pid, grp in revs.groupby('product_id'):
            texts = [clean_text(x) for x in grp['review_text_clean'].dropna().tolist()]
            if not texts: continue
            pros, cons = simple_pros_cons(texts)
            verdict = "Overall sentiment is positive." if len(pros) >= len(cons) else "Overall sentiment is mixed/negative."
            insts.append({
                "instruction": "Summarize customer reviews into Pros, Cons, and a Verdict.",
                "input": f"Product_ID: {pid}\nReviews:\n" + "\n".join(texts[:12]),
                "output": f"Pros: {pros}\nCons: {cons}\nVerdict: {verdict}"
            })

    # write JSONL
    os.makedirs(os.path.dirname(out_jsonl), exist_ok=True)
    with open(out_jsonl, "w", encoding="utf-8") as f:
        for ex in insts:
            f.write(json.dumps(ex, ensure_ascii=False) + "\n")
    print(f"[OK] Wrote {len(insts)} instruction examples to {out_jsonl}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--silver-dir", default="data/silver")
    ap.add_argument("--out-jsonl", default="data/silver/electronics_instruct.jsonl")
    args = ap.parse_args()
    products_csv = os.path.join(args.silver_dir, "electronics_products_master.csv")
    reviews_csv  = os.path.join(args.silver_dir, "electronics_reviews_events.csv")
    build_instructions(products_csv, reviews_csv, args.out_jsonl)
