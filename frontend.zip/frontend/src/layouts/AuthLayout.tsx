
import { Link } from 'react-router-dom'

export default function AuthLayout({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', background: '#f3f4f6' }}>
      <div className="card" style={{ width: 420 }}>
        <div className="card-header" style={{ justifyContent: 'center' }}>
          <h2 style={{ margin: 0 }}>{title}</h2>
        </div>
        <div className="card-body">{children}</div>
        <div className="card-footer" style={{ justifyContent: 'center' }}>
          <div style={{ display: 'flex', gap: 12 }}>
            <Link to="/">Home</Link>
            <Link to="/login">Login</Link>
            <Link to="/register">Register</Link>
          </div>
        </div>
      </div>
    </div>
  )
}
