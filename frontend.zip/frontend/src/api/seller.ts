
import { api } from './client'
import { SellerInsightsOut } from '../types/personas'

export async function getSellerInsights(
  productId: number,
  params?: { start?: string; end?: string; topk?: number }
): Promise<SellerInsightsOut> {
  const { data } = await api.get(`/seller/product/${productId}/insights`, { params })
  return data
}
