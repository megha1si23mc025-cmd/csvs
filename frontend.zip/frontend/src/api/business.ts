
import { api } from './client'
import { BusinessTrendOut, BusinessCompareOut } from '../types/personas'

export async function getCategoryTrends(category: string, start?: string, end?: string): Promise<BusinessTrendOut> {
  const { data } = await api.get(`/business/category/${encodeURIComponent(category)}/trends`, { params: { start, end } })
  return data
}

export async function compareProducts(productIds: Array<number | string>): Promise<BusinessCompareOut> {
  const ids = productIds.map(String).join(',')
  const { data } = await api.get(`/business/compare`, { params: { product_ids: ids } })
  return data
}
