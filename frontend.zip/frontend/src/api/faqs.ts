
import { api } from './client'
import { FAQOut, FAQCreateIn, FAQUpdateIn } from '../types/faq'

/**
 * Helper: returns data if request succeeds. If 404, returns provided fallback.
 * Otherwise rethrows the error to be handled by the caller/query.
 */
async function safeGet<T>(path: string, params?: any, notFoundFallback?: T): Promise<T> {
  try {
    const { data } = await api.get(path, { params })
    return data as T
  } catch (e: any) {
    const status = e?.response?.status
    if (status === 404 && notFoundFallback !== undefined) {
      return notFoundFallback
    }
    throw e
  }
}

export async function getProductFaqs(productId: number, limit = 100): Promise<FAQOut[]> {
  // Treat 404 as "no FAQs yet" to avoid failing the UI
  return safeGet<FAQOut[]>(`/faqs/product/${productId}`, { limit }, [])
}

export async function searchFaqs(q: string, productId?: number, limit = 50): Promise<FAQOut[]> {
  const params: any = { q, limit }
  if (productId) params.product_id = productId
  const { data } = await api.get(`/faqs/search`, { params })
  return data as FAQOut[]
}

export async function createFaq(payload: FAQCreateIn): Promise<FAQOut> {
  const { data } = await api.post(`/faqs`, payload)
  return data as FAQOut
}

export async function updateFaq(id: number, payload: FAQUpdateIn): Promise<FAQOut> {
  const { data } = await api.patch(`/faqs/${id}`, payload)
  return data as FAQOut
}

export async function deleteFaq(id: number): Promise<{ ok: boolean }> {
  const { data } = await api.delete(`/faqs/${id}`)
  return data as { ok: boolean }
}
