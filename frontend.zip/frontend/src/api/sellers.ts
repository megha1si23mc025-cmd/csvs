
import { api } from './client'
import { ProductOut } from '../types/product'
import { SellerOut } from '../types/seller'

export async function listSellers(limit = 100): Promise<SellerOut[]> {
  const { data } = await api.get('/sellers', { params: { limit } })
  return data
}

export async function listSellerProducts(sellerId: number, limit = 200): Promise<ProductOut[]> {
  const { data } = await api.get(`/sellers/${sellerId}/products`, { params: { limit } })
  return data
}
