
import { api } from './client'
import type { UserOut, Role } from '../types/user'

// If your backend uses different paths, adjust here.
type LoginIn = { email: string; password: string }
type RegisterIn = { email: string; password: string; full_name?: string; role?: Role }

export async function me(): Promise<UserOut | null> {
  try {
    const { data } = await api.get('/auth/me')
    return data as UserOut
  } catch (e: any) {
    const status = e?.response?.status
    // Treat 401/404 as "not signed in"
    if (status === 401 || status === 404) return null
    throw e
  }
}

export async function login(payload: LoginIn): Promise<{ ok: boolean }> {
  const { data } = await api.post('/auth/login', payload)
  return data as { ok: boolean }
}

export async function logout(): Promise<{ ok: boolean }> {
  const { data } = await api.post('/auth/logout')
  return data as { ok: boolean }
}

export async function register(payload: RegisterIn): Promise<{ ok: boolean; user?: UserOut }> {
  const { data } = await api.post('/auth/register', payload)
  return data as { ok: boolean; user?: UserOut }
}

// Re-export type for compatibility if other modules import from api/auth
export type { UserOut } from '../types/user'
