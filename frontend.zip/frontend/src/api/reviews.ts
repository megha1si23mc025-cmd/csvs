
import { api } from './client'
import { ReviewOut } from '../types/review'

export async function getProductReviews(productId: number): Promise<ReviewOut[]> {
  const { data } = await api.get(`/reviews/product/${productId}`)
  return data
}
