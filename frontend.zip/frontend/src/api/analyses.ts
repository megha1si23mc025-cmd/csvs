
import { api } from './client'
import { AnalysisOut } from '../types/analysis'

export async function getAnalysis(reviewId: number): Promise<AnalysisOut> {
  const { data } = await api.get(`/analyses/${reviewId}`)
  return data
}
