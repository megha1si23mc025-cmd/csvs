
import { api } from './client'
import { SupportListOut } from '../types/personas'

export async function getProductUrgent(productId: number, limit = 100): Promise<SupportListOut> {
  const { data } = await api.get(`/support/product/${productId}/urgent`, { params: { limit } })
  return data
}

export async function getGlobalNegative(limit = 100): Promise<SupportListOut> {
  const { data } = await api.get(`/support/reviews/negative`, { params: { limit } })
  return data
}
