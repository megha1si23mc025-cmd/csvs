
import { api } from './client'
import { SentimentTrendOut, KeyIssuesOut } from '../types/dashboards'

export async function getSentimentTrend(productId: number, start?: string, end?: string): Promise<SentimentTrendOut> {
  const { data } = await api.get(`/dashboards/product/${productId}/sentiment-trend`, { params: { start, end } })
  return data
}

export async function getKeyIssues(productId: number, limit = 20): Promise<KeyIssuesOut> {
  const { data } = await api.get(`/dashboards/product/${productId}/key-issues`, { params: { limit } })
  return data
}
