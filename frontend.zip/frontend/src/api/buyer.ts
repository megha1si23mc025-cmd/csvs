
import { api } from './client'
import { BuyerSummaryOut } from '../types/personas'

export async function getBuyerSummary(
  productId: number,
  params?: { pros_limit?: number; cons_limit?: number; quotes_per_polarity?: number }
): Promise<BuyerSummaryOut> {
  const { data } = await api.get(`/buyer/product/${productId}/summary`, { params })
  return data
}
