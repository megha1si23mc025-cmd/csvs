
import { api } from './client'
import { ProductOut } from '../types/product'

export async function getProduct(productId: number): Promise<ProductOut> {
  const { data } = await api.get(`/products/by-id/${productId}`)
  return data
}

export async function listProducts(limit = 50, sellerId?: number): Promise<ProductOut[]> {
  const params: any = { limit }
  if (sellerId !== undefined) params.seller_id = sellerId
  const { data } = await api.get(`/products`, { params })
  return data
}

export async function searchProducts(q: string, limit = 50, sellerId?: number): Promise<ProductOut[]> {
  const params: any = { q, limit }
  if (sellerId !== undefined) params.seller_id = sellerId
  const { data } = await api.get(`/products/search`, { params })
  return data
}
