
import axios from 'axios'

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000',
  withCredentials: true, // send cookies for auth
  headers: {
    'Content-Type': 'application/json',
  },
})

// Optional response interceptor to standardize messages
api.interceptors.response.use(
  (res) => res,
  (err) => {
    // Keep original error, but ensure message is readable
    const status = err?.response?.status
    const detail = err?.response?.data?.detail
    err.message = detail ? String(detail) : err.message || `HTTP ${status ?? 'Error'}`
    return Promise.reject(err)
  }
)
