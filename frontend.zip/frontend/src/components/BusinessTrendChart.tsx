
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, Legend } from 'recharts'

export default function BusinessTrendChart({ points }: { points: Array<{ date: string; sentiment: string; count: number }> }) {
  const byDate: Record<string, any> = {}
  points.forEach((p) => {
    const d = p.date
    if (!byDate[d]) byDate[d] = { date: d, positive: 0, negative: 0, neutral: 0, unknown: 0 }
    byDate[d][p.sentiment] = p.count
  })
  const data = Object.values(byDate).sort((a: any, b: any) => (a.date < b.date ? -1 : 1))

  if (data.length === 0) {
    return <div>-</div>
  }

  return (
    <div style={{ width: '100%', height: 320 }}>
      <ResponsiveContainer>
        <LineChart data={data as any[]}>
          <XAxis dataKey="date" />
          <YAxis allowDecimals={false} />
          <Tooltip />
          <Legend />
          <Line dataKey="positive" stroke="#16a34a" />
          <Line dataKey="neutral" stroke="#64748b" />
          <Line dataKey="negative" stroke="#dc2626" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
