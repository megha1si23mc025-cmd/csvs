
import { ReviewOut } from '../types/review'
import dayjs from 'dayjs'

export default function ReviewCard({ review, rightSlot }: { review: ReviewOut; rightSlot?: React.ReactNode }){
  return (
    <div className="card">
      <div className="card-header">
        <strong>{review.review_title || 'Review'}</strong>
        <div>{rightSlot}</div>
      </div>
      <div className="card-body">
        <p>{review.review_text}</p>
      </div>
      <div className="card-footer" style={{ gap: 12 }}>
        <span>By {review.reviewer_name || 'Anonymous'}</span>
        <span>Date {dayjs(review.review_date).format('YYYY-MM-DD')}</span>
        <span>Rating {review.rating ?? '-'}</span>
        <span>Verified {review.verified_purchase ? 'Yes' : 'No'}</span>
        <span>Helpful {review.helpful_votes}</span>
      </div>
    </div>
  )
}
