
import { useQuery } from '@tanstack/react-query'
import { getBuyerSummary } from '../api/buyer'
import { BuyerSummaryOut } from '../types/personas'

export default function BuyerView({ productId }: { productId: number }) {
  const q = useQuery({
    queryKey: ['buyerSummary', productId],
    queryFn: () => getBuyerSummary(productId, { pros_limit: 5, cons_limit: 5, quotes_per_polarity: 2 }),
    enabled: Number.isFinite(productId),
  })

  if (q.isLoading) return <div className="card"><div className="card-body">Loading Buyer Summary…</div></div>
  if (q.error || !q.data) return <div className="card"><div className="card-body">Failed to load Buyer Summary.</div></div>

  const data: BuyerSummaryOut = q.data
  return (
    <div className="card">
      <div className="card-header"><strong>Buyer Summary</strong></div>
      <div className="card-body">
        {data.summary && (
          <>
            <h3 style={{ marginTop: 0 }}>Summary</h3>
            <p>{data.summary}</p>
          </>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <div>
            <h4>Pros</h4>
            {data.pros.length === 0 ? <div>-</div> : (
              <ul>
                {data.pros.map((p) => (
                  <li key={p.label}>{p.label} <span style={{ color: '#6b7280' }}>({p.count})</span></li>
                ))}
              </ul>
            )}
          </div>
          <div>
            <h4>Cons</h4>
            {data.cons.length === 0 ? <div>-</div> : (
              <ul>
                {data.cons.map((c) => (
                  <li key={c.label}>{c.label} <span style={{ color: '#6b7280' }}>({c.count})</span></li>
                ))}
              </ul>
            )}
          </div>
        </div>

        <div style={{ marginTop: 12, display: 'flex', gap: 16 }}>
          <div>Average rating: <strong>{data.average_rating ?? '-'}</strong></div>
          {data.verdict && <div>Verdict: <strong>{data.verdict}</strong></div>}
        </div>

        <div style={{ marginTop: 16, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <div>
            <h4>Recent Positive Quotes</h4>
            {data.quotes_positive.length === 0 ? <div>-</div> : (
              <ul style={{ paddingLeft: 16 }}>
                {data.quotes_positive.map((q, i) => (
                  <li key={i}>
                    <div style={{ fontStyle: 'italic' }}>"{q.text}"</div>
                    <div style={{ color: '#6b7280' }}>
                      {q.date} — Rating {q.rating ?? '-'} — Helpful {q.helpful_votes} — {q.reviewer_name || 'Anonymous'}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div>
            <h4>Recent Negative Quotes</h4>
            {data.quotes_negative.length === 0 ? <div>-</div> : (
              <ul style={{ paddingLeft: 16 }}>
                {data.quotes_negative.map((q, i) => (
                  <li key={i}>
                    <div style={{ fontStyle: 'italic' }}>"{q.text}"</div>
                    <div style={{ color: '#6b7280' }}>
                      {q.date} — Rating {q.rating ?? '-'} — Helpful {q.helpful_votes} — {q.reviewer_name || 'Anonymous'}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
