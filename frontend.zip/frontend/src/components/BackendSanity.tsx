
import { useEffect, useState } from 'react'
import { api } from '../api/client'

type CheckResult = {
  name: string
  ok: boolean
  status?: number
  message?: string
}

type Props = {
  productId?: number
}

export default function BackendSanity({ productId }: Props) {
  const [results, setResults] = useState<CheckResult[]>([])
  const [running, setRunning] = useState(false)

  useEffect(() => {
    runChecks()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [productId])

  async function runChecks() {
    setRunning(true)
    const tasks: Array<Promise<CheckResult>> = []

    // 0) Base URL reachability (simple GET to root or health endpoint)
    tasks.push(
      (async () => {
        const base = api.defaults.baseURL || ''
        try {
          const res = await api.get('/') // change if your backend has /health
          return { name: `BASE ${base}`, ok: true, status: res.status }
        } catch (e: any) {
          const status = e?.response?.status
          const msg = e?.message || e?.response?.data?.detail || 'Unknown error'
          return { name: `BASE ${base}`, ok: false, status, message: msg }
        }
      })()
    )

    // 1) FAQs for product
    if (Number.isFinite(productId)) {
      tasks.push(
        (async () => {
          try {
            const res = await api.get(`/faqs/product/${productId}`, { params: { limit: 1 } })
            return { name: 'GET /faqs/product/:id', ok: true, status: res.status }
          } catch (e: any) {
            const status = e?.response?.status
            const msg = e?.message || e?.response?.data?.detail || 'Unknown error'
            // 404 is acceptable (means: no FAQs yet)
            if (status === 404) {
              return { name: 'GET /faqs/product/:id', ok: true, status, message: 'No FAQs yet (404)' }
            }
            return { name: 'GET /faqs/product/:id', ok: false, status, message: msg }
          }
        })()
      )
    }

    // 2) Sellers listing (used by useSellerId hook)
    tasks.push(
      (async () => {
        try {
          const res = await api.get('/sellers', { params: { limit: 1 } })
          return { name: 'GET /sellers', ok: true, status: res.status }
        } catch (e: any) {
          const status = e?.response?.status
          const msg = e?.message || e?.response?.data?.detail || 'Unknown error'
          return { name: 'GET /sellers', ok: false, status, message: msg }
        }
      })()
    )

    // 3) Auth check (me) — tolerate 401/404 as OK when not signed in
    tasks.push(
      (async () => {
        try {
          const res = await api.get('/auth/me')
          return { name: 'GET /auth/me', ok: true, status: res.status }
        } catch (e: any) {
          const status = e?.response?.status
          const msg = e?.message || e?.response?.data?.detail || 'Unknown error'
          if (status === 401 || status === 404) {
            return { name: 'GET /auth/me', ok: true, status, message: 'Not signed in (401/404) — acceptable' }
          }
          return { name: 'GET /auth/me', ok: false, status, message: msg }
        }
      })()
    )

    const r = await Promise.all(tasks)
    setResults(r)
    setRunning(false)
  }

  return (
    <div className="card" style={{ marginTop: 12 }}>
      <div className="card-header">
        <strong>Backend Sanity</strong>
        <button
          onClick={runChecks}
          style={{ background: '#e5e7eb', color: '#111827' }}
          disabled={running}
        >
          {running ? 'Checking…' : 'Re-run'}
        </button>
      </div>
      <div className="card-body" style={{ display: 'grid', gap: 8 }}>
        {results.length === 0 && <div>Running initial checks…</div>}
        {results.map((r) => (
          <div key={r.name} style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <span
              className="badge"
              style={{ background: r.ok ? '#16a34a' : '#dc2626', color: '#fff', minWidth: 60, textAlign: 'center' }}
            >
              {r.ok ? 'OK' : 'FAIL'}
            </span>
            <div style={{ flex: 1 }}>
              <div><strong>{r.name}</strong></div>
              <div style={{ color: '#6b7280' }}>
                Status: {r.status ?? '-'}{r.message ? ` — ${r.message}` : ''}
              </div>
            </div>
          </div>
        ))}

        <div style={{ marginTop: 8, color: '#6b7280' }}>
          If an endpoint fails:
          <ul style={{ marginTop: 6 }}>
            <li>Verify backend path & method exist (e.g., <code>GET /faqs/product/:id</code>).</li>
            <li>Check CORS middleware — many frameworks don’t handle <code>OPTIONS</code> without configuration.</li>
            <li>For auth, define <code>GET /auth/me</code> (returns user or 401/404 when logged out).</li>
            <li>For empty data, return <code>404</code> or <code>200 []</code>; frontend now tolerates both for FAQs.</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
