
import { Outlet, NavLink, Link } from 'react-router-dom'
import { paths } from '../../routes/paths'
import { useAuth } from '../../context/AuthContext'

export default function AppLayout() {
  const { user, logout } = useAuth()

  return (
    <div>
      <header style={{ position: 'sticky', top: 0, zIndex: 1000, background: '#111827', color: '#fff', boxShadow: '0 2px 8px rgba(0,0,0,0.2)' }}>
        <div className="container" style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
          <h3 style={{ margin: 0 }}>Review Intelligence</h3>
          <nav style={{ display: 'flex', gap: 12 }}>
            <NavLink to={paths.home} style={({ isActive }) => ({ color: '#fff', opacity: isActive ? 1 : 0.85 })}>Home</NavLink>
            <NavLink to={paths.products} style={({ isActive }) => ({ color: '#fff', opacity: isActive ? 1 : 0.85 })}>Products</NavLink>
            <NavLink to={paths.business} style={({ isActive }) => ({ color: '#fff', opacity: isActive ? 1 : 0.85 })}>Business</NavLink>
            <NavLink to={paths.admin} style={({ isActive }) => ({ color: '#fff', opacity: isActive ? 1 : 0.85 })}>Admin</NavLink>
          </nav>
          <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 8 }}>
            {user ? (
              <>
                <span style={{ color: '#cbd5e1' }}>{user.full_name || user.email}</span>
                <span className="badge" style={{ background: '#2563eb' }}>{user.role || 'user'}</span>
                <button onClick={logout} style={{ background: '#e11d48' }}>Logout</button>
              </>
            ) : (
              <>
                <Link to="/login" style={{ color: '#fff' }}>Login</Link>
                <Link to="/register" style={{ color: '#fff' }}>Register</Link>
              </>
            )}
          </div>
        </div>
      </header>
      <main>
        <Outlet />
      </main>
    </div>
  )
}
