
import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { FAQOut, FAQCreateIn, FAQUpdateIn } from '../types/faq'
import { getProductFaqs, createFaq, updateFaq, deleteFaq } from '../api/faqs'
import { useAuth } from '../context/AuthContext'

type Props = { productId: number }

export default function FAQManager({ productId }: Props) {
  const { hasRole } = useAuth()
  const canEdit = hasRole('seller', 'admin')
  const qc = useQueryClient()

  const listQ = useQuery({
    queryKey: ['faqs', productId],
    queryFn: () => getProductFaqs(productId, 200),
    enabled: Number.isFinite(productId),
  })

  const [form, setForm] = useState<FAQCreateIn>({
    product_id: productId,
    question: '',
    answer: '',
    tags: [],
    visibility: 'public',
  })

  const createM = useMutation({
    mutationFn: (payload: FAQCreateIn) => createFaq(payload),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['faqs', productId] })
      setForm({ product_id: productId, question: '', answer: '', tags: [], visibility: 'public' })
    },
  })

  const updateM = useMutation({
    mutationFn: (args: { id: number; data: FAQUpdateIn }) => updateFaq(args.id, args.data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['faqs', productId] }),
  })

  const deleteM = useMutation({
    mutationFn: (id: number) => deleteFaq(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['faqs', productId] }),
  })

  if (!canEdit) return null

  return (
    <div className="card">
      <div className="card-header"><strong>Manage FAQs</strong></div>
      <div className="card-body" style={{ display: 'grid', gap: 12 }}>
        <div style={{ display: 'grid', gap: 8 }}>
          <label>Question</label>
          <input value={form.question} onChange={(e) => setForm({ ...form, question: e.target.value })} />
          <label>Answer</label>
          <textarea
            value={form.answer}
            onChange={(e) => setForm({ ...form, answer: e.target.value })}
            style={{ minHeight: 90 }}
          />
          <label>Tags (comma separated)</label>
          <input
            value={(form.tags || []).join(', ')}
            onChange={(e) =>
              setForm({ ...form, tags: e.target.value.split(',').map(x => x.trim()).filter(Boolean) })
            }
          />
          <label>Visibility</label>
          <select
            value={form.visibility || 'public'}
            onChange={(e) => setForm({ ...form, visibility: e.target.value as any })}
          >
            <option value="public">Public</option>
            <option value="private">Private</option>
            <option value="internal">Internal</option>
          </select>
          <div>
            <button
              onClick={() => createM.mutate(form)}
              disabled={!form.question.trim() || !form.answer.trim() || createM.isPending}
            >
              {createM.isPending ? 'Adding…' : 'Add FAQ'}
            </button>
          </div>
        </div>

        <hr />

        {listQ.isLoading && <div>Loading existing FAQs…</div>}
        {listQ.error && <div style={{ color: '#dc2626' }}>Failed to load FAQs.</div>}
        {listQ.data && listQ.data.length === 0 && <div>No FAQs yet.</div>}
        {listQ.data && listQ.data.length > 0 && (
          <div style={{ display: 'grid', gap: 8 }}>
            {listQ.data.map((f: FAQOut) => (
              <div key={f.id} className="card" style={{ marginBottom: 0 }}>
                <div className="card-header">
                  <strong>{f.question}</strong>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button
                      style={{ background: '#e5e7eb', color: '#111827' }}
                      onClick={() =>
                        updateM.mutate({
                          id: f.id,
                          data: { visibility: f.visibility === 'public' ? 'private' : 'public' },
                        })
                      }
                    >
                      Toggle Visibility
                    </button>
                    <button
                      style={{ background: '#dc2626' }}
                      onClick={() => deleteM.mutate(f.id)}
                    >
                      Delete
                    </button>
                  </div>
                </div>
                <div className="card-body">
                  <div style={{ whiteSpace: 'pre-wrap' }}>{f.answer}</div>
                  <div style={{ marginTop: 8, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                    {f.tags?.map(t => (
                      <span key={t} className="badge" style={{ background: '#eef2ff', color: '#3730a3' }}>{t}</span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
