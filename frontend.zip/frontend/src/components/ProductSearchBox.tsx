
import { useEffect, useRef, useState } from 'react'
import { searchProducts } from '../api/products'
import { ProductOut } from '../types/product'

type Props = {
  placeholder?: string
  onSelect: (p: ProductOut) => void
  maxSuggestions?: number
  /**
   * Optional: when provided, search results are restricted to this seller's catalog.
   */
  sellerId?: number
}

export default function ProductSearchBox({
  placeholder = 'Search products (title, brand, SKU)…',
  onSelect,
  maxSuggestions = 10,
  sellerId,
}: Props) {
  const [value, setValue] = useState<string>('')
  const [open, setOpen] = useState<boolean>(false)
  const [loading, setLoading] = useState<boolean>(false)
  const [error, setError] = useState<string>('')
  const [suggestions, setSuggestions] = useState<ProductOut[]>([])
  const [highlight, setHighlight] = useState<number>(-1)

  const containerRef = useRef<HTMLDivElement | null>(null)
  const inputRef = useRef<HTMLInputElement | null>(null)
  const debounceRef = useRef<number | null>(null)
  const blurTimerRef = useRef<number | null>(null)

  // Debounced search
  useEffect(() => {
    if (debounceRef.current) {
      window.clearTimeout(debounceRef.current)
      debounceRef.current = null
    }
    if (value.trim().length < 1) {
      setSuggestions([])
      setOpen(false)
      setError('')
      setLoading(false)
      setHighlight(-1)
      return
    }
    setLoading(true)
    setError('')
    debounceRef.current = window.setTimeout(async () => {
      try {
        const res = await searchProducts(value.trim(), maxSuggestions, sellerId)
        setSuggestions(res || [])
        setOpen(true)
        setHighlight(res && res.length > 0 ? 0 : -1)
      } catch (e: any) {
        setError(e?.message || 'Search failed')
        setSuggestions([])
        setOpen(true)
        setHighlight(-1)
      } finally {
        setLoading(false)
      }
    }, 220)
    return () => {
      if (debounceRef.current) {
        window.clearTimeout(debounceRef.current)
        debounceRef.current = null
      }
    }
  }, [value, maxSuggestions, sellerId])

  // Close list on outside click
  useEffect(() => {
    function onPointerDownDoc(e: PointerEvent) {
      if (!containerRef.current) return
      const target = e.target as Node
      if (!containerRef.current.contains(target)) {
        setOpen(false)
      }
    }
    document.addEventListener('pointerdown', onPointerDownDoc)
    return () => document.removeEventListener('pointerdown', onPointerDownDoc)
  }, [])

  function handleSelect(p: ProductOut) {
    setOpen(false)
    setValue(p.product_title) // optional: reflect selection in input
    onSelect(p)
  }

  function onKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (!open) return
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setHighlight((h) => {
        const next = Math.min(suggestions.length - 1, h < 0 ? 0 : h + 1)
        return next
      })
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setHighlight((h) => {
        const prev = Math.max(0, h < 0 ? 0 : h - 1)
        return prev
      })
    } else if (e.key === 'Enter') {
      e.preventDefault()
      if (highlight >= 0 && highlight < suggestions.length) {
        handleSelect(suggestions[highlight])
      }
    } else if (e.key === 'Escape') {
      e.preventDefault()
      setOpen(false)
    }
  }

  // Delay closing on blur so a click on a suggestion still registers
  function onBlur() {
    if (blurTimerRef.current) {
      window.clearTimeout(blurTimerRef.current)
    }
    blurTimerRef.current = window.setTimeout(() => {
      setOpen(false)
    }, 120)
  }

  return (
    <div ref={containerRef} className="autocomplete-container" style={{ position: 'relative' }}>
      <input
        ref={inputRef}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={onKeyDown}
        onFocus={() => (suggestions.length > 0) && setOpen(true)}
        onBlur={onBlur}
        placeholder={placeholder}
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls="product-suggestions"
        style={{ width: '100%', padding: '6px 8px', border: '1px solid #d1d5db', borderRadius: 6 }}
      />

      {open && (
        <div
          id="product-suggestions"
          className="autocomplete-list"
          role="listbox"
          style={{
            position: 'absolute',
            top: '100%',
            left: 0,
            right: 0,
            background: '#fff',
            border: '1px solid #e5e7eb',
            borderRadius: 8,
            marginTop: 4,
            zIndex: 1000, // ensure above other elements
            maxHeight: 280,
            overflowY: 'auto',
            boxShadow: '0 6px 24px rgba(0,0,0,0.08)',
          }}
        >
          {loading && <div className="autocomplete-item" style={{ padding: '8px 12px' }}>Searching…</div>}
          {!loading && error && (
            <div className="autocomplete-item" style={{ padding: '8px 12px', color: '#dc2626' }}>
              Error: {error}
            </div>
          )}
          {!loading && !error && suggestions.length === 0 && (
            <div className="autocomplete-item" style={{ padding: '8px 12px' }}>
              No results.
            </div>
          )}
          {!loading && !error && suggestions.map((p, idx) => {
            const active = idx === highlight
            return (
              <div
                key={p.id}
                role="option"
                aria-selected={active}
                className="autocomplete-item"
                onPointerDown={(e) => {
                  // pointerdown fires before input blur — perfect for selection
                  e.preventDefault()
                  e.stopPropagation()
                  handleSelect(p)
                }}
                onMouseEnter={() => setHighlight(idx)}
                style={{
                  padding: '8px 12px',
                  cursor: 'pointer',
                  background: active ? '#eff6ff' : '#fff',
                  borderBottom: '1px solid #f3f4f6',
                }}
              >
                <div style={{ display: 'flex', gap: 8 }}>
                  <strong style={{ flex: 1 }}>{p.product_title}</strong>
                  <span style={{ color: '#6b7280' }}>#{p.id}</span>
                </div>
                <div style={{ display: 'flex', gap: 12, color: '#6b7280', fontSize: 12 }}>
                  <span>{p.brand || '-'}</span>
                  <span>{p.category}</span>
                  <span>SKU: {p.sku}</span>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
