
export default function ThemeChip({ label }: { label: string }){
  return (
    <span style={{
      display: 'inline-block',
      padding: '4px 8px',
      borderRadius: 16,
      background: '#eef2ff',
      color: '#3730a3',
      fontSize: 12,
    }}>
      {label}
    </span>
  )
}
