
import { useQuery } from '@tanstack/react-query'
import { getAnalysis } from '../api/analyses'

function colorFor(sentiment: string){
  switch (sentiment){
    case 'positive': return '#16a34a'
    case 'neutral': return '#64748b'
    case 'negative': return '#dc2626'
    default: return '#374151'
  }
}

export default function SentimentBadge({ reviewId }: { reviewId: number }){
  const q = useQuery({ queryKey: ['analysis', reviewId], queryFn: () => getAnalysis(reviewId) })
  if (q.isLoading) return <span className="badge" style={{ background: '#e5e7eb' }}>…</span>
  if (q.error || !q.data) return null
  const s = q.data.sentiment || 'unknown'
  return <span className="badge" style={{ background: colorFor(s), color: '#fff' }}>{s}</span>
}
