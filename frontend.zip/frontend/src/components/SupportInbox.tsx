
import { SupportIssueOut } from '../types/personas'

export default function SupportInbox({ items }: { items: SupportIssueOut[] }) {
  if (!items || items.length === 0) {
    return <div className="card"><div className="card-body">No urgent items found.</div></div>
  }

  const badgeColor = (sev: number) => {
    if (sev >= 5) return '#dc2626' // red
    if (sev >= 4) return '#f97316' // orange
    if (sev >= 3) return '#f59e0b' // amber
    return '#64748b' // slate
  }

  return (
    <div style={{ display: 'grid', gap: 8 }}>
      {items.map((it) => (
        <div key={it.review_id} className="card">
          <div className="card-header">
            <strong>#{it.review_id}</strong>
            <span className="badge" style={{ background: badgeColor(it.severity), color: '#fff' }}>Severity {it.severity}</span>
          </div>
          <div className="card-body">
            <div style={{ marginBottom: 8 }}>
              <span style={{ fontWeight: 600 }}>Issue:</span> {it.top_issue || '-'}
            </div>
            <div style={{ fontStyle: 'italic' }}>"{it.excerpt}"</div>
          </div>
          <div className="card-footer" style={{ gap: 12 }}>
            <span>Date {it.review_date}</span>
            <span>Rating {it.rating ?? '-'}</span>
            <span>Helpful {it.helpful_votes}</span>
            <span>Sentiment {it.sentiment}</span>
            <span>By {it.reviewer_name || 'Anonymous'}</span>
          </div>
        </div>
      ))}
    </div>
  )
}
