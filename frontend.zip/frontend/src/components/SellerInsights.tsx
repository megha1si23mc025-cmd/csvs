
import { useQuery } from '@tanstack/react-query'
import { getSellerInsights } from '../api/seller'
import { SellerInsightsOut, CountItem } from '../types/personas'
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, Legend } from 'recharts'

function List({ title, items }: { title: string; items: CountItem[] }) {
  return (
    <div className="card" style={{ flex: 1 }}>
      <div className="card-header"><strong>{title}</strong></div>
      <div className="card-body">
        {items.length === 0 ? <div>-</div> : (
          <ul>
            {items.map((it) => (
              <li key={it.label}>{it.label} <span style={{ color: '#6b7280' }}>({it.count})</span></li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}

export default function SellerInsights({ productId }: { productId: number }) {
  const q = useQuery({
    queryKey: ['sellerInsights', productId],
    queryFn: () => getSellerInsights(productId, { topk: 10 }),
    enabled: Number.isFinite(productId),
  })

  if (q.isLoading) return <div className="card"><div className="card-body">Loading Seller Insights…</div></div>
  if (q.error || !q.data) return <div className="card"><div className="card-body">Failed to load Seller Insights.</div></div>

  const data: SellerInsightsOut = q.data

  // Prepare trend points grouped by date
  const byDate: Record<string, any> = {}
  data.trend_points.forEach((p) => {
    const d = p.date
    if (!byDate[d]) byDate[d] = { date: d, positive: 0, negative: 0, neutral: 0, unknown: 0 }
    byDate[d][p.sentiment] = p.count
  })
  const chartData = Object.values(byDate).sort((a: any, b: any) => (a.date < b.date ? -1 : 1))

  return (
    <div style={{ display: 'grid', gap: 16 }}>
      <div style={{ display: 'flex', gap: 16 }}>
        <List title="Top Pros" items={data.pros_top} />
        <List title="Top Cons" items={data.cons_top} />
      </div>

      <div className="card">
        <div className="card-header"><strong>Sentiment Distribution</strong></div>
        <div className="card-body">
          {data.sentiment_distribution.length === 0 ? <div>-</div> : (
            <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
              {data.sentiment_distribution.map((d) => (
                <div key={d.label} className="badge" style={{ background: '#eef2ff', color: '#3730a3' }}>
                  {d.label}: {d.count}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="card">
        <div className="card-header"><strong>Key Issues</strong></div>
        <div className="card-body">
          {data.key_issues.length === 0 ? <div>-</div> : (
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              {data.key_issues.map((it) => (
                <span key={it.label} style={{ padding: '4px 8px', borderRadius: 16, background: '#eef2ff', color: '#3730a3' }}>
                  {it.label} ({it.count})
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="card">
        <div className="card-header"><strong>Sentiment Trend</strong></div>
        <div className="card-body" style={{ width: '100%', height: 320 }}>
          {chartData.length === 0 ? <div>-</div> : (
            <ResponsiveContainer>
              <LineChart data={chartData as any[]}>
                <XAxis dataKey="date" />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Legend />
                <Line dataKey="positive" stroke="#16a34a" />
                <Line dataKey="neutral" stroke="#64748b" />
                <Line dataKey="negative" stroke="#dc2626" />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  )
}
