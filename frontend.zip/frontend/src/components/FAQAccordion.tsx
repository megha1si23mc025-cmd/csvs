
import { useState } from 'react'
import { FAQOut } from '../types/faq'

export default function FAQAccordion({ items }: { items: FAQOut[] }) {
  const [openId, setOpenId] = useState<number | null>(null)

  if (!items || items.length === 0) {
    return <div className="card"><div className="card-body">No FAQs yet.</div></div>
  }

  return (
    <div style={{ display: 'grid', gap: 8 }}>
      {items.map(f => {
        const isOpen = openId === f.id
        return (
          <div key={f.id} className="card">
            <button
              onClick={() => setOpenId(isOpen ? null : f.id)}
              className="accordion-button"
              aria-expanded={isOpen}
              style={{
                display: 'flex',
                width: '100%',
                textAlign: 'left',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '12px',
                background: '#f8fafc',
                borderBottom: '1px solid #e5e7eb',
              }}
            >
              <strong>{f.question}</strong>
              <span style={{ color: '#6b7280' }}>{isOpen ? '−' : '+'}</span>
            </button>
            {isOpen && (
              <div className="card-body">
                <div style={{ whiteSpace: 'pre-wrap' }}>{f.answer}</div>
                <div style={{ marginTop: 8, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {f.tags?.map(t => (
                    <span key={t} className="badge" style={{ background: '#eef2ff', color: '#3730a3' }}>
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}
