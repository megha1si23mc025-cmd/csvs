
import { ThemeCount } from '../types/dashboards'
import ThemeChip from './ThemeChip'

export default function KeyIssuesList({ themes }: { themes: ThemeCount[] }){
  if (!themes || themes.length === 0) return <div>No key issues found.</div>
  return (
    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
      {themes.map((t) => (
        <ThemeChip key={t.theme} label={`${t.theme} (${t.count})`} />
      ))}
    </div>
  )
}
