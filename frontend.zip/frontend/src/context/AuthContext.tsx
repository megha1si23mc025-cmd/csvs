
import { createContext, useContext, useEffect, useState } from 'react'
import { me as apiMe, login as apiLogin, logout as apiLogout, register as apiRegister } from '../api/auth'
import { UserOut, Role } from '../types/user'

type AuthCtx = {
  user: UserOut | null
  loading: boolean
  login: (email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  register: (email: string, password: string, full_name?: string, role?: Role) => Promise<void>
  hasRole: (...roles: Role[]) => boolean
}

const Ctx = createContext<AuthCtx>({
  user: null,
  loading: false,
  login: async () => {},
  logout: async () => {},
  register: async () => {},
  hasRole: () => false,
})

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<UserOut | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    ;(async () => {
      try {
        const u = await apiMe()
        setUser(u) // null when not signed in
      } catch {
        setUser(null)
      } finally {
        setLoading(false)
      }
    })()
  }, [])

  async function login(email: string, password: string) {
    await apiLogin({ email, password })
    const u = await apiMe()
    setUser(u)
  }

  async function register(email: string, password: string, full_name?: string, role: Role = 'buyer') {
    await apiRegister({ email, password, full_name, role })
    await login(email, password)
  }

  async function logout() {
    await apiLogout()
    setUser(null)
  }

  function hasRole(...roles: Role[]) {
    return !!user && !!user.role && roles.includes(user.role)
  }

  return (
    <Ctx.Provider value={{ user, loading, login, logout, register, hasRole }}>
      {children}
    </Ctx.Provider>
  )
}

export function useAuth() {
  return useContext(Ctx)
}
