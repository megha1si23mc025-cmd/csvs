
export type ReviewOut = {
  id: number;
  product_id: number;
  rating: number | null;
  review_title: string | null;
  review_text: string;
  review_date: string;
  reviewer_name: string | null;
  verified_purchase: boolean;
  helpful_votes: number;
  source: string | null;
}
