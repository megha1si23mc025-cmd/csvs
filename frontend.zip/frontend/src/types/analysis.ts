
export type AnalysisOut = {
  review_id: number;
  summary?: string | null;
  pros?: string[] | null;
  cons?: string[] | null;
  sentiment: 'positive' | 'neutral' | 'negative' | 'unknown' | string;
  verdict?: string | null;
  key_themes?: Array<{ theme: string; [k: string]: any }> | null;
}
