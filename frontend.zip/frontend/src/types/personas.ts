
export type CountItem = { label: string; count: number }

export type BuyerQuote = {
  text: string
  rating?: number | null
  date: string
  sentiment?: string | null
  helpful_votes: number
  reviewer_name?: string | null
}

export type BuyerSummaryOut = {
  product_id: number
  summary?: string | null
  pros: CountItem[]
  cons: CountItem[]
  verdict?: string | null
  average_rating?: number | null
  quotes_positive: BuyerQuote[]
  quotes_negative: BuyerQuote[]
}

export type SellerInsightsOut = {
  product_id: number
  pros_top: CountItem[]
  cons_top: CountItem[]
  sentiment_distribution: CountItem[]
  key_issues: CountItem[]
  trend_points: Array<{ date: string; sentiment: string; count: number }>
}

// ---- Support types ----
export type SupportIssueOut = {
  review_id: number
  product_id: number
  review_date: string
  rating?: number | null
  reviewer_name?: string | null
  helpful_votes: number
  sentiment: string
  top_issue?: string | null
  severity: number
  excerpt: string
}

export type SupportListOut = {
  items: SupportIssueOut[]
}

// ---- Business types ----
export type BusinessTrendOut = {
  points: Array<{ date: string; sentiment: string; count: number }>
}

export type ProductCompareItem = {
  product_id: number
  average_rating?: number | null
  issues_top: CountItem[]
  last30_trend: Array<{ date: string; sentiment: string; count: number }>
}

export type BusinessCompareOut = {
  items: ProductCompareItem[]
}
