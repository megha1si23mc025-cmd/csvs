
export type SentimentPoint = { date: string; sentiment: string; count: number }
export type SentimentTrendOut = { points: SentimentPoint[] }
export type ThemeCount = { theme: string; count: number }
export type KeyIssuesOut = { themes: ThemeCount[] }
