
export type Role = 'buyer' | 'seller' | 'support' | 'admin' | 'manager';

export type UserOut = {
  id: number | string;
  email: string;
  full_name?: string | null;
  role?: Role | null;
  seller_id?: number | string | null;
  external_id?: string | null;
};
