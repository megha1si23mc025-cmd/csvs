
export type SellerOut = {
  id: number
  external_id: string
  name: string
  email?: string | null
}
