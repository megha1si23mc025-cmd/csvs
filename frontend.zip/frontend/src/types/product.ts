
export type ProductOut = {
  id: number;
  sku: string;
  product_title: string;
  brand: string | null;
  category: string;
  subtype: string | null;
  price: number | null;
  source: string | null;
  external_id: string | null;
}
