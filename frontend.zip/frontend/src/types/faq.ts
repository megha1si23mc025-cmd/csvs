
export type FAQOut = {
  id: number
  product_id?: number | null
  question: string
  answer: string
  tags?: string[] | null
  visibility?: 'public' | 'private' | 'internal' | string
  author_name?: string | null
  created_at?: string
  updated_at?: string
}

export type FAQCreateIn = {
  product_id?: number | null
  question: string
  answer: string
  tags?: string[]
  visibility?: 'public' | 'private' | 'internal'
}

export type FAQUpdateIn = Partial<FAQCreateIn>
