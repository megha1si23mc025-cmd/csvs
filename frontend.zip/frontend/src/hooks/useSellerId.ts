
import { useEffect, useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { listSellers } from '../api/sellers'

const CACHE_KEY = 'sellerIdByUserId'

type CacheMap = { [userId: string]: number }

export function useSellerId() {
  const { user } = useAuth()
  const [sellerId, setSellerId] = useState<number | undefined>(undefined)
  const [loading, setLoading] = useState<boolean>(false)

  useEffect(() => {
    let cancelled = false

    async function resolve() {
      if (!user || user.role !== 'seller') {
        setSellerId(undefined)
        return
      }

      // 1) direct from backend (string | number)
      const rawSid = user.seller_id
      if (rawSid !== null && rawSid !== undefined) {
        const sid = typeof rawSid === 'string' ? parseInt(rawSid, 10) : rawSid
        if (Number.isFinite(sid)) {
          setSellerId(sid as number)
          return
        }
      }

      // 2) local cache by user.id (string | number)
      try {
        const raw = localStorage.getItem(CACHE_KEY)
        const cache: CacheMap = raw ? JSON.parse(raw) : {}
        const cached = cache[String(user.id)]
        if (cached && Number.isFinite(cached)) {
          setSellerId(cached)
          return
        }
      } catch {}

      // 3) heuristic: match by email or external_id from sellers list
      setLoading(true)
      try {
        const sellers = await listSellers(1000)
        const normalizedEmail = (user.email || '').trim().toLowerCase()
        const normalizedExt = (user.external_id || '').trim()

        const match = sellers.find(s => {
          const sEmail = (s.email || '').trim().toLowerCase()
          const sExt = (s.external_id || '').trim()
          return (normalizedEmail && sEmail && sEmail === normalizedEmail) ||
                 (normalizedExt && sExt && sExt === normalizedExt)
        })

        if (!cancelled && match?.id) {
          setSellerId(match.id)
          // cache it
          try {
            const raw = localStorage.getItem(CACHE_KEY)
            const cache: CacheMap = raw ? JSON.parse(raw) : {}
            cache[String(user.id)] = match.id
            localStorage.setItem(CACHE_KEY, JSON.stringify(cache))
          } catch {}
        }
      } finally {
        if (!cancelled) setLoading(false)
      }
    }

    resolve()
    return () => { cancelled = true }
  }, [user])

  return { sellerId, loading }
}
