
import { useState, useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { getCategoryTrends, compareProducts } from '../api/business'
import BusinessTrendChart from '../components/BusinessTrendChart'
import ProductSearchBox from '../components/ProductSearchBox'
import { ProductCompareItem } from '../types/personas'
import { ProductOut } from '../types/product'

export default function BusinessDashboard() {
  // Category-level trend controls
  const [category, setCategory] = useState<string>('Electronics')
  const [start, setStart] = useState<string>('')      // e.g., '2025-01-01'
  const [end, setEnd] = useState<string>('')          // e.g., '2025-12-31'

  // Product comparison via autocomplete (two products)
  const [prodA, setProdA] = useState<ProductOut | null>(null)
  const [prodB, setProdB] = useState<ProductOut | null>(null)

  // Queries
  const trendQ = useQuery({
    queryKey: ['businessTrend', category, start, end],
    queryFn: () => getCategoryTrends(category, start || undefined, end || undefined),
  })

  const compareIds = useMemo(() => {
    const ids: number[] = []
    if (prodA?.id) ids.push(prodA.id)
    if (prodB?.id) ids.push(prodB.id)
    return ids
  }, [prodA, prodB])

  const compareQ = useQuery({
    queryKey: ['businessCompare', compareIds.join(',')],
    queryFn: () => compareProducts(compareIds),
    enabled: compareIds.length === 2, // require exactly two products selected
  })

  return (
    <div className="container">
      <h1>Business Dashboard</h1>

      {/* Controls */}
      <div className="card">
        <div className="card-header"><strong>Controls</strong></div>
        <div className="card-body" style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 16 }}>
          {/* Category Trend Controls */}
          <div className="card" style={{ margin: 0 }}>
            <div className="card-header"><strong>Category Trend</strong></div>
            <div className="card-body" style={{ display: 'grid', gap: 8 }}>
              <div>
                <label>Category</label>
                <input value={category} onChange={(e) => setCategory(e.target.value)} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                <div>
                  <label>Start (YYYY-MM-DD)</label>
                  <input value={start} onChange={(e) => setStart(e.target.value)} />
                </div>
                <div>
                  <label>End (YYYY-MM-DD)</label>
                  <input value={end} onChange={(e) => setEnd(e.target.value)} />
                </div>
              </div>
            </div>
          </div>

          {/* Product Comparison via Search */}
          <div className="card" style={{ margin: 0 }}>
            <div className="card-header"><strong>Compare Two Products</strong></div>
            <div className="card-body" style={{ display: 'grid', gap: 12 }}>
              <div>
                <label style={{ display: 'block', marginBottom: 4 }}>Product A</label>
                <ProductSearchBox
                  placeholder="Search product A (title, brand, SKU)…"
                  maxSuggestions={10}
                  onSelect={(p) => setProdA(p)}
                />
                {prodA && (
                  <div style={{ marginTop: 6, color: '#6b7280' }}>
                    Selected A: <strong>{prodA.product_title}</strong> — #{prodA.id} — SKU {prodA.sku}
                    <button
                      onClick={() => setProdA(null)}
                      style={{ marginLeft: 8, background: '#e5e7eb', color: '#111827' }}
                    >
                      Clear
                    </button>
                  </div>
                )}
              </div>

              <div>
                <label style={{ display: 'block', marginBottom: 4 }}>Product B</label>
                <ProductSearchBox
                  placeholder="Search product B (title, brand, SKU)…"
                  maxSuggestions={10}
                  onSelect={(p) => setProdB(p)}
                />
                {prodB && (
                  <div style={{ marginTop: 6, color: '#6b7280' }}>
                    Selected B: <strong>{prodB.product_title}</strong> — #{prodB.id} — SKU {prodB.sku}
                    <button
                      onClick={() => setProdB(null)}
                      style={{ marginLeft: 8, background: '#e5e7eb', color: '#111827' }}
                    >
                      Clear
                    </button>
                  </div>
                )}
              </div>

              <div style={{ color: '#6b7280' }}>
                {compareIds.length !== 2 && 'Select two products to compare.'}
                {compareIds.length === 2 && 'Comparing selected products…'}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Category Trend */}
      <section style={{ marginTop: 16 }}>
        <h2>Category Sentiment Trend — {category}</h2>
        {trendQ.isLoading && <div>Loading trend…</div>}
        {trendQ.error && <div>Failed to load trend.</div>}
        {trendQ.data && <BusinessTrendChart points={trendQ.data.points} />}
      </section>

      {/* Product Comparison */}
      <section style={{ marginTop: 24 }}>
        <h2>Compare Products</h2>
        {compareIds.length !== 2 && <div>Select Product A and Product B above.</div>}
        {compareIds.length === 2 && compareQ.isLoading && <div>Loading comparison…</div>}
        {compareIds.length === 2 && compareQ.error && <div>Failed to load comparison.</div>}
        {compareIds.length === 2 && compareQ.data && (
          <div style={{ display: 'grid', gap: 12, gridTemplateColumns: '1fr 1fr' }}>
            {compareQ.data.items.map((it: ProductCompareItem) => (
              <div key={it.product_id} className="card">
                <div className="card-header"><strong>Product #{it.product_id}</strong></div>
                <div className="card-body">
                  <div style={{ marginBottom: 8 }}>
                    Avg Rating: <strong>{it.average_rating ?? '-'}</strong>
                  </div>

                  <div style={{ marginBottom: 8 }}>
                    <div style={{ fontWeight: 600 }}>Top Issues</div>
                    {it.issues_top.length === 0 ? <div>-</div> : (
                      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                        {it.issues_top.map((x) => (
                          <span key={x.label} className="badge" style={{ background: '#eef2ff', color: '#3730a3' }}>
                            {x.label} ({x.count})
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  <div>
                    <div style={{ fontWeight: 600, marginBottom: 4 }}>Sentiment (Last 30 days)</div>
                    <BusinessTrendChart points={it.last30_trend} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  )
}
