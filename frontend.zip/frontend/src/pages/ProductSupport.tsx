
import { useParams, Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { getProduct } from '../api/products'
import { getProductUrgent } from '../api/support'
import SupportInbox from '../components/SupportInbox'
import { paths } from '../routes/paths'

export default function ProductSupport() {
  const { productId } = useParams<{ productId: string }>()
  const pid = Number(productId)

  if (!Number.isFinite(pid)) {
    return (
      <div className="container">
        <h1>Invalid product id</h1>
        <p>
          The product id <code>{String(productId)}</code> is not a valid number. Try picking one from{' '}
          <Link to={paths.products}>Products list</Link>.
        </p>
      </div>
    )
  }

  const productQ = useQuery({
    queryKey: ['product', pid],
    queryFn: () => getProduct(pid),
    enabled: Number.isFinite(pid),
    retry: false,
  })
  const urgentQ = useQuery({
    queryKey: ['supportUrgent', pid],
    queryFn: () => getProductUrgent(pid, 100),
    enabled: Number.isFinite(pid) && productQ.isSuccess,
  })

  if (productQ.isLoading) return <div className="container">Loading…</div>
  if (productQ.error) return <div className="container">Error loading product.</div>

  const product = productQ.data!

  return (
    <div className="container">
      <h1>Support Inbox — {product.product_title}</h1>

      {/* Clean persona page: no navigation links here */}

      <section style={{ marginTop: 16 }}>
        <h2>Urgent & Negative Reviews</h2>
        {urgentQ.isLoading && <div>Loading support items…</div>}
        {urgentQ.error && <div>Failed to load support items.</div>}
        {urgentQ.data && <SupportInbox items={urgentQ.data.items} />}
      </section>
    </div>
  )
}
