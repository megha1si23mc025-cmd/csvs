
// Add below your existing cards in AdminImport
import { useState } from 'react'
import { api } from '../api/client'

// ... keep your existing component code ...

export default function AdminImport(){
  const [bootstrapStatus, setBootstrapStatus] = useState<string>('')
  const [bootstrapRunning, setBootstrapRunning] = useState(false)

  const runBootstrap = async (productId?: number) => {
    setBootstrapRunning(true); setBootstrapStatus('')
    try {
      const { data } = await api.get('/admin/bootstrap-analyses', { params: { limit: 2000, product_id: productId } })
      setBootstrapStatus(JSON.stringify(data, null, 2))
    } catch (e: any) {
      setBootstrapStatus(`Error: ${e.message}`)
    } finally {
      setBootstrapRunning(false)
    }
  }

  return (
    <div className="container">
      {/* ... your existing two import cards ... */}

      <div className="card" style={{ marginTop: 12 }}>
        <div className="card-header"><strong>Bootstrap Analyses (No LLM)</strong></div>
        <div className="card-body">
          <p>Generate heuristic pros/cons & sentiment so Buyer/Seller views work immediately.</p>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <button onClick={() => runBootstrap()} disabled={bootstrapRunning}>
              {bootstrapRunning ? 'Running…' : 'Bootstrap All (limit 2000)'}
            </button>
            {/* Optional: field for a specific product */}
            {/* <button onClick={() => runBootstrap(1)} disabled={bootstrapRunning}>Bootstrap Product #1</button> */}
          </div>
          {bootstrapStatus && <pre style={{ whiteSpace: 'pre-wrap', marginTop: 12 }}>{bootstrapStatus}</pre>}
        </div>
      </div>
    </div>
  )
}
