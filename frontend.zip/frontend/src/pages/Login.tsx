
import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import AuthLayout from '../layouts/AuthLayout'
import { paths } from '../routes/paths'

export default function LoginPage() {
  const { login } = useAuth()
  const nav = useNavigate()

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      await login(email, password)
      // decide route based on role
      const u = JSON.parse(localStorage.getItem("auth_user") || "null")
      if (!u?.role) nav(paths.home)

      switch (u.role) {
        case 'buyer':   nav(paths.home); break
        case 'seller':  nav(paths.sellerProduct(1)); break // or homepage for sellers
        case 'support': nav(paths.productSupport(1)); break
        case 'admin':   nav(paths.admin); break
        default:        nav(paths.home)
      }
    } catch (e: any) {
      setError(e.message || "Login failed")
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthLayout title="Login">
      <form onSubmit={submit} style={{ display: 'grid', gap: 12 }}>
        <label>Email</label>
        <input value={email} onChange={(e) => setEmail(e.target.value)} />

        <label>Password</label>
        <input type='password' value={password} onChange={(e) => setPassword(e.target.value)} />

        {error && <div style={{ color: '#dc2626' }}>{error}</div>}

        <button disabled={loading}>{loading ? "Logging in…" : "Login"}</button>
      </form>

      <div style={{ marginTop: 12 }}>
        Buyers can register here: <Link to="/register">Register</Link>
      </div>
    </AuthLayout>
  )
}
