
import { useQuery } from '@tanstack/react-query'
import { searchFaqs, deleteFaq } from '../api/faqs'
import { useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { FAQOut } from '../types/faq'

export default function AdminFAQs() {
  const qc = useQueryClient()
  const [q, setQ] = useState('')
  const listQ = useQuery({
    queryKey: ['adminFaqs', q],
    queryFn: () => searchFaqs(q, undefined, 500),
  })
  const delM = useMutation({
    mutationFn: (id: number) => deleteFaq(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['adminFaqs', q] }),
  })
  return (
    <div className="container">
      <h1>Admin — FAQs</h1>
      <div className="card">
        <div className="card-body" style={{ display: 'flex', gap: 8 }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search question, tags…" />
          <button onClick={() => listQ.refetch()}>Search</button>
        </div>
      </div>
      {listQ.isLoading && <div>Loading…</div>}
      {listQ.error && <div style={{ color: '#dc2626' }}>Failed to load.</div>}
      {listQ.data && (
        <div style={{ display: 'grid', gap: 8 }}>
          {listQ.data.map((f: FAQOut) => (
            <div key={f.id} className="card">
              <div className="card-header">
                <strong>#{f.id}</strong>
                <div style={{ display: 'flex', gap: 8 }}>
                  <span className="badge" style={{ background: '#eef2ff', color: '#3730a3' }}>
                    Product {f.product_id ?? '—'}
                  </span>
                  <span className="badge" style={{ background: '#e5e7eb', color: '#111827' }}>
                    {f.visibility || 'public'}
                  </span>
                  <button style={{ background: '#dc2626' }} onClick={() => delM.mutate(f.id)}>Delete</button>
                </div>
              </div>
              <div className="card-body">
                <div><strong>Q:</strong> {f.question}</div>
                <div style={{ marginTop: 6 }}><strong>A:</strong> <div style={{ whiteSpace: 'pre-wrap' }}>{f.answer}</div></div>
                <div style={{ marginTop: 6, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {f.tags?.map(t => <span key={t} className="badge" style={{ background: '#eef2ff', color: '#3730a3' }}>{t}</span>)}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
