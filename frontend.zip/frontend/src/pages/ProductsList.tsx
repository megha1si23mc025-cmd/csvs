
import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { listProducts } from '../api/products'
import { paths } from '../routes/paths'

export default function ProductsList() {
  const q = useQuery({ queryKey: ['productsList'], queryFn: () => listProducts(100) })

  if (q.isLoading) return <div className="container">Loading products…</div>
  if (q.error) return <div className="container">Failed to load products.</div>

  const rows = q.data || []
  return (
    <div className="container">
      <h1>Products</h1>
      {rows.length === 0 && <p>No products yet. Import via <Link to={paths.admin}>Admin</Link>.</p>}
      <ul>
        {rows.map(p => (
          <li key={p.id}>
            <Link to={paths.product(p.id)}>
              #{p.id} — {p.product_title} {p.brand ? `(${p.brand})` : ''} [{p.category}] — SKU: {p.sku}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  )
}
