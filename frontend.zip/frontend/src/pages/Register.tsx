
import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import AuthLayout from '../layouts/AuthLayout'
import { useAuth } from '../context/AuthContext'
import { Role } from '../types/user'

export default function RegisterPage() {
  const { register } = useAuth()
  const nav = useNavigate()

  const [email, setEmail] = useState('')
  const [fullName, setFullName] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      await register(email, password, fullName, 'buyer')
      nav('/')
    } catch (e: any) {
      setError(e.message || "Registration failed")
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthLayout title="Register (Buyers)">
      <form onSubmit={submit} style={{ display: 'grid', gap: 12 }}>
        <label>Full Name</label>
        <input value={fullName} onChange={(e) => setFullName(e.target.value)} />

        <label>Email</label>
        <input value={email} onChange={(e) => setEmail(e.target.value)} />

        <label>Password</label>
        <input type='password' value={password} onChange={(e) => setPassword(e.target.value)} />

        {error && <div style={{ color: '#dc2626' }}>{error}</div>}

        <button disabled={loading}>{loading ? "Registering…" : "Register"}</button>
      </form>

      <div style={{ marginTop: 12 }}>
        Already have an account? <Link to="/login">Login</Link>
      </div>
    </AuthLayout>
  )
}
