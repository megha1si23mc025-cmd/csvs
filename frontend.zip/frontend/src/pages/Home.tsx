
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import ProductSearchBox from '../components/ProductSearchBox'
import { paths } from '../routes/paths'
import { ProductOut } from '../types/product'
import { useAuth } from '../context/AuthContext'
import { useSellerId } from '../hooks/useSellerId'

type Persona = 'buyer' | 'seller' | 'support' | 'manager'

export default function Home(){
  const nav = useNavigate()
  const [persona, setPersona] = useState<Persona>('buyer')
  const { user } = useAuth()
  const { sellerId, loading: sellerLoading } = useSellerId()

  function goTo(p: Persona, product: ProductOut | null){
    if (p === 'manager'){
      nav(paths.business)
      return
    }
    if (!product) return
    const id = product.id
    switch (p){
      case 'buyer':  nav(paths.buyerProduct(id));  break
      case 'seller': nav(paths.sellerProduct(id)); break
      case 'support':nav(paths.productSupport(id)); break
    }
  }

  return (
    <div className="container">
      <h1>Who are you?</h1>
      <p>Select your role and search for a product by <strong>name, brand, or SKU</strong>.</p>

      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        {(['buyer','seller','support','manager'] as Persona[]).map(p => (
          <button
            key={p}
            onClick={() => setPersona(p)}
            style={{
              background: persona === p ? '#2563eb' : '#e5e7eb',
              color: persona === p ? '#fff' : '#111827'
            }}
          >
            {p === 'buyer'   && 'Buyer'}
            {p === 'seller'  && 'Seller'}
            {p === 'support' && 'Support'}
            {p === 'manager' && 'Manager'}
          </button>
        ))}
      </div>

      <div className="card">
        <div className="card-header">
          <strong>Search</strong>
          {persona === 'manager' && (
            <div>
              <button onClick={() => goTo('manager', null)}>Go to Business Dashboard</button>
            </div>
          )}
        </div>
        <div className="card-body">
          <ProductSearchBox
            onSelect={(p) => goTo(persona, p)}
            maxSuggestions={10}
            placeholder="Search products (title, brand, SKU)…"
            sellerId={persona === 'seller' ? sellerId : undefined}
          />
          {persona === 'seller' && user?.role !== 'seller' && (
            <div style={{ marginTop: 8, color: '#dc2626' }}>
              Sign in as a seller to see only your products.
            </div>
          )}
          {persona === 'seller' && user?.role === 'seller' && !sellerId && (
            <div style={{ marginTop: 8, color: '#6b7280' }}>
              {sellerLoading ? 'Resolving seller profile…' : 'Could not resolve your seller id.'}
            </div>
          )}
          <div style={{ marginTop: 8, color: '#6b7280' }}>
            Tip: Use arrow keys to navigate suggestions, <kbd>Enter</kbd> to open.
          </div>
        </div>
      </div>
    </div>
  )
}
