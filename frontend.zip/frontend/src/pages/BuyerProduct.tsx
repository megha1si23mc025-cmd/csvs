
import { useParams, Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { getProduct } from '../api/products'
import BuyerView from '../components/BuyerView'
import { paths } from '../routes/paths'
import { getProductFaqs } from '../api/faqs'
import FAQAccordion from '../components/FAQAccordion'

export default function BuyerProduct() {
  const { productId } = useParams<{ productId: string }>()
  const pid = Number(productId)

  // Guard: invalid product id
  if (!Number.isFinite(pid)) {
    return (
      <div className="container">
        <h1>Invalid product id</h1>
        <p>
          The product id <code>{String(productId)}</code> is not a valid number.
          Try picking one from <Link to={paths.products}>Products list</Link>.
        </p>
      </div>
    )
  }

  // Load product
  const productQ = useQuery({
    queryKey: ['product', pid],
    queryFn: () => getProduct(pid),
    enabled: Number.isFinite(pid),
    retry: false,
  })

  // FAQs
  const faqsQ = useQuery({
    queryKey: ['faqs', pid],
    queryFn: () => getProductFaqs(pid, 100),
    enabled: Number.isFinite(pid) && productQ.isSuccess,
  })

  if (productQ.isLoading) return <div className="container">Loading…</div>
  if (productQ.error) {
    const status = (productQ.error as any)?.response?.status
    if (status === 404) {
      return (
        <div className="container">
          <h1>Product not found</h1>
          <p>
            The product with id <code>{productId}</code> doesn’t exist.
            Try importing data via <Link to={paths.admin}>Admin</Link> or pick one from the{' '}
            <Link to={paths.products}>Products list</Link>.
          </p>
        </div>
      )
    }
    return <div className="container">Error loading product.</div>
  }

  const product = productQ.data!

  // --- Buyer-only layout (no extra persona links) ---
  return (
    <div className="container">
      <h1>{product.product_title}</h1>

      <div className="meta">
        <span>Brand: {product.brand || '-'}</span>
        <span>Category: {product.category}</span>
        <span>Price: {product.price ?? '-'}</span>
        <span>SKU: {product.sku}</span>
        <span>External: {product.external_id ?? '-'}</span>
      </div>

      {/* Buyer summary, pros/cons, quotes */}
      <section style={{ marginTop: 16 }}>
        <BuyerView productId={pid} />
      </section>

      {/* FAQs */}
      <section style={{ marginTop: 24 }}>
        <h2>FAQs</h2>
        <div style={{ marginBottom: 8 }}>
          <Link to={paths.productFaqs(pid)}>Open full FAQs page</Link>
        </div>
        {faqsQ.isLoading && <div>Loading FAQs…</div>}
        {faqsQ.error && <div style={{ color: '#dc2626' }}>Failed to load FAQs.</div>}
        {faqsQ.data && <FAQAccordion items={faqsQ.data} />}
      </section>
    </div>
  )
}
