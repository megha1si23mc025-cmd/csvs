
import { useParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { getSentimentTrend, getKeyIssues } from '../api/dashboards'
import TrendChart from '../components/TrendChart'
import KeyIssuesList from '../components/KeyIssuesList'

export default function ProductDashboards(){
  const { productId } = useParams()
  const pid = Number(productId)

  const trendQ = useQuery({ queryKey: ['sentimentTrend', pid], queryFn: () => getSentimentTrend(pid), enabled: Number.isFinite(pid) })
  const issuesQ = useQuery({ queryKey: ['keyIssues', pid], queryFn: () => getKeyIssues(pid), enabled: Number.isFinite(pid) })

  if (trendQ.isLoading || issuesQ.isLoading) return <div className="container">Loading dashboards…</div>
  if (trendQ.error || issuesQ.error) return <div className="container">Failed to load dashboards.</div>

  return (
    <div className="container">
      <h1>Dashboards</h1>
      <section style={{ marginTop: 16 }}>
        <h2>Sentiment Trend</h2>
        <TrendChart points={trendQ.data!.points} />
      </section>
      <section style={{ marginTop: 24 }}>
        <h2>Key Issues</h2>
        <KeyIssuesList themes={issuesQ.data!.themes} />
      </section>
    </div>
  )
}
