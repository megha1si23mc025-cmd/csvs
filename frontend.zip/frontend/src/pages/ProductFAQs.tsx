
import { useParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { getProduct } from '../api/products'
import { getProductFaqs } from '../api/faqs'
import FAQAccordion from '../components/FAQAccordion'
import FAQManager from '../components/FAQManager'
import BackendSanity from '../components/BackendSanity'

export default function ProductFAQs() {
  const { productId } = useParams<{ productId: string }>()
  const pid = Number(productId)

  const productQ = useQuery({
    queryKey: ['product', pid],
    queryFn: () => getProduct(pid),
    enabled: Number.isFinite(pid),
    retry: false,
  })

  const faqsQ = useQuery({
    queryKey: ['faqs', pid],
    queryFn: () => getProductFaqs(pid, 200),
    enabled: Number.isFinite(pid) && productQ.isSuccess,
    // If you want to avoid stale data flicker:
    staleTime: 5_000,
  })

  if (!Number.isFinite(pid)) return <div className="container">Invalid product id.</div>
  if (productQ.isLoading) return <div className="container">Loading…</div>
  if (productQ.error) return <div className="container">Product not found or error.</div>

  const product = productQ.data!

  return (
    <div className="container">
      <h1>FAQs — {product.product_title}</h1>

      {/* FAQs list */}
      <section style={{ marginTop: 16 }}>
        {faqsQ.isLoading && <div>Loading FAQs…</div>}
        {!faqsQ.isLoading && faqsQ.data && faqsQ.data.length === 0 && (
          <div className="card"><div className="card-body">No FAQs yet.</div></div>
        )}
        {faqsQ.error && (
          <div style={{ color: '#dc2626' }}>
            Failed to load FAQs.
          </div>
        )}
        {!faqsQ.isLoading && !faqsQ.error && faqsQ.data && faqsQ.data.length > 0 && (
          <FAQAccordion items={faqsQ.data} />
        )}
      </section>

      {/* Manage (seller/admin) */}
      <section style={{ marginTop: 16 }}>
        <FAQManager productId={pid} />
      </section>

      {/* Backend sanity checks panel */}
      <section style={{ marginTop: 16 }}>
        <BackendSanity productId={pid} />
      </section>
    </div>
  )
}
