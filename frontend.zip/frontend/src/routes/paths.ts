
export const paths = {
  home: '/',
  products: '/products',
  product: (id: number | string) => `/product/${id}`,
  buyerProduct: (id: number | string) => `/buyer/product/${id}`,
  sellerProduct: (id: number | string) => `/seller/product/${id}`,
  dashboards: (id: number | string) => `/product/${id}/dashboards`,
  productSupport: (id: number | string) => `/product/${id}/support`,
  productFaqs: (id: number | string) => `/product/${id}/faqs`,
  business: '/business',
  admin: '/admin/import',
}
