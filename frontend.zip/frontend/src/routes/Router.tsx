
import { createBrowserRouter, RouterProvider } from 'react-router-dom'

// Layout
import AppLayout from '../components/Layout/AppLayout'

// Pages
import Home from '../pages/Home'
import LoginPage from '../pages/Login'
import RegisterPage from '../pages/Register'
import ProductsList from '../pages/ProductsList'
import ProductDetail from '../pages/ProductDetail'
import BuyerProduct from '../pages/BuyerProduct'
import SellerProduct from '../pages/SellerProduct'
import ProductDashboards from '../pages/ProductDashboards'
import ProductSupport from '../pages/ProductSupport'
import BusinessDashboard from '../pages/BusinessDashboard'
import AdminImport from '../pages/AdminImport'
import ProductFAQs from '../pages/ProductFAQs'
import AdminFAQs from '../pages/AdminFAQs' // optional admin page

const router = createBrowserRouter([
  {
    path: '/',
    element: <AppLayout />,
    children: [
      // Landing with persona selector + product search/autocomplete
      { index: true, element: <Home /> },
        
{ path: 'login', element: <LoginPage /> },
{ path: 'register', element: <RegisterPage /> },

      // Generic list of products (kept for utility/debug)
      { path: 'products', element: <ProductsList /> },

      // Persona-specific clean product pages
      { path: 'buyer/product/:productId', element: <BuyerProduct /> },
      { path: 'seller/product/:productId', element: <SellerProduct /> },

      // Generic product detail (mixed view; optional to keep)
      { path: 'product/:productId', element: <ProductDetail /> },

      // Product dashboards
      { path: 'product/:productId/dashboards', element: <ProductDashboards /> },

      // Product Support Inbox (persona: support)
      { path: 'product/:productId/support', element: <ProductSupport /> },

      // Product FAQs (public page)
      { path: 'product/:productId/faqs', element: <ProductFAQs /> },

      // Business / Manager dashboard
      { path: 'business', element: <BusinessDashboard /> },

      // Admin imports & tools
      { path: 'admin/import', element: <AdminImport /> },

      // Admin FAQs (optional)
      { path: 'admin/faqs', element: <AdminFAQs /> },
    ],
  },
])

export default function AppRouter() {
  return <RouterProvider router={router} />
}
